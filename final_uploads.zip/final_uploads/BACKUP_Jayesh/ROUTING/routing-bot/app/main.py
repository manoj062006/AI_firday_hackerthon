from fastapi import FastAPI
from app.models.message import ChatRequest, ChatResponse
from app.models.enums import RouteType
from app.routing.state_manager import (
    has_conversation_started,
    mark_conversation_started,
)
from app.routing.router import route_message
from app.routing.intent_and_emotion import IntentType

from app.db.session import SessionLocal
from app.db.queries import get_user_plan, get_user_recharge

from app.llm_providers.local_llm import call_local_llm
from app.llm_providers.premium_llm import call_premium_llm

from app.llm_providers.prompt_builder import (
    build_db_prompt,
    build_simple_help_prompt,
    build_failure_prompt,
)

app = FastAPI(title="Empathetic AI Helpdesk Bot (Local + Premium)")


@app.get("/")
def health_check():
    return {
        "status": "ok",
        "message": "Empathetic Routing Bot API is running (local + premium)",
    }


@app.post("/chat", response_model=ChatResponse)
def chat_endpoint(request: ChatRequest):

    # ✅ 1. START MESSAGE (ONLY ONCE PER USER)
    if not has_conversation_started(request.user_id):
        mark_conversation_started(request.user_id)
        return ChatResponse(
            user_id=request.user_id,
            reply="How can I help you today?",
            route_used=RouteType.NORMAL,
        )

    user_message = request.message.strip()

    # ✅ 2. ROUTING (intent + emotion + route type)
    route_type, intent, emotion = route_message(user_message)

    # ✅ 3. GREETING → Static, warm
    if intent == IntentType.GREETING:
        return ChatResponse(
            user_id=request.user_id,
            reply="Hi there! 😊 What can I help you with today?",
            route_used=RouteType.NORMAL,
        )

    # ✅ 4. DB QUERY → DB → LOCAL LLM (data + light emotion)
    if intent == IntentType.DB_QUERY:
        db = SessionLocal()
        plan = get_user_plan(db, request.user_id)
        recharge = get_user_recharge(db, request.user_id)
        db.close()

        if plan:
            db_context = f"""
Plan Name: {plan.plan_name}
Benefits: {plan.benefits}
Data Left: {plan.data_balance}
Validity Till: {plan.validity_end}
"""
        else:
            db_context = "No plan information found."

        local_prompt = build_db_prompt(
            user_message=user_message,
            emotion=emotion,
            db_context=db_context,
        )

        reply = call_local_llm(local_prompt)

        return ChatResponse(
            user_id=request.user_id,
            reply=reply.strip(),
            route_used=RouteType.LOCAL_LLM,
        )

    # ✅ 5. LOCAL_LLM ROUTE (simple help / other)
    if route_type == RouteType.LOCAL_LLM:
        local_prompt = build_simple_help_prompt(
            user_message=user_message,
            emotion=emotion,
        )

        reply = call_local_llm(local_prompt)

        return ChatResponse(
            user_id=request.user_id,
            reply=reply.strip(),
            route_used=RouteType.LOCAL_LLM,
        )

    # ✅ 6. PREMIUM_LLM ROUTE (failures / problems)
    if route_type == RouteType.PREMIUM_LLM:
        premium_prompt = build_failure_prompt(
            user_message=user_message,
            emotion=emotion,
        )

        reply = call_premium_llm(premium_prompt)

        return ChatResponse(
            user_id=request.user_id,
            reply=reply.strip(),
            route_used=RouteType.PREMIUM_LLM,
        )

    # ✅ 7. FINAL FALLBACK
    return ChatResponse(
        user_id=request.user_id,
        reply="I’m here to help — tell me a bit more 😊",
        route_used=RouteType.NORMAL,
    )
