from typing import Optional

from app.config import (
    PREMIUM_LLM_API_KEY,
    PREMIUM_LLM_BASE_URL,
    PREMIUM_LLM_MODEL,
)

# Make sure you have: pip install langchain-openai
from langchain_openai import ChatOpenAI

# You can later replace this with a custom httpx client if needed
client: Optional[object] = None


def get_premium_llm() -> ChatOpenAI:
    """
    Returns a configured premium LLM client using environment configuration.
    """

    if not PREMIUM_LLM_API_KEY:
        raise ValueError("PREMIUM_LLM_API_KEY is not set in environment")

    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model="gemini-2.5-pro",
        api_key="sk-QIOxO8UXL369Fc6SBzAPPw",
        http_client=client
    )

    return llm


def call_premium_llm(prompt: str) -> str:
    """
    Unified method used by router for premium requests.
    Uses .invoke() which is the correct modern LangChain interface.
    """

    llm = get_premium_llm()
    response = llm.invoke(prompt)

    # response is usually an AIMessage with .content
    content = getattr(response, "content", None)
    if isinstance(content, str):
        return content

    return str(response)
