from app.routing.intent_and_emotion import EmotionType


# -------------------------
# TONE CONTROL BY EMOTION
# -------------------------
def emotion_tone(emotion: EmotionType) -> str:
    if emotion == EmotionType.ANGRY:
        return "Be calm, apologetic, and reassuring."
    elif emotion == EmotionType.FRUSTRATED:
        return "Be supportive and gently reassuring."
    elif emotion == EmotionType.CONFUSED:
        return "Be patient, clear, and explanatory."
    elif emotion == EmotionType.HAPPY:
        return "Be cheerful and friendly."
    else:
        return "Be warm, neutral, and friendly."


# -------------------------
# ✅ DB → LOCAL LLM PROMPT (DATA + EMOTION)
# -------------------------
def build_db_prompt(user_message: str, emotion: EmotionType, db_context: str) -> str:
    tone = emotion_tone(emotion)

    return f"""
You are a friendly customer support assistant.

Tone rule:
{tone}

User asked:
"{user_message}"

Here is the user's real account data:
{db_context}

Reply rules:
- Answer using ONLY this data
- Sound human and natural
- Keep it under 3–4 short sentences
- Do NOT sound like therapy
- Do NOT add fake sympathy
- Be helpful and clear
"""


# -------------------------
# ✅ SIMPLE HELP → LOCAL LLM PROMPT
# -------------------------
def build_simple_help_prompt(user_message: str, emotion: EmotionType) -> str:
    tone = emotion_tone(emotion)

    return f"""
You are a helpful and friendly assistant.

Tone rule:
{tone}

User asked:
"{user_message}"

Reply rules:
- Be clear and simple
- No emotional over-talk
- No long explanations
- Sound like a real human helper
"""


# -------------------------
# ✅ FAILURE / PROBLEM → PREMIUM LLM PROMPT
# -------------------------
def build_failure_prompt(user_message: str, emotion: EmotionType) -> str:
    tone = emotion_tone(emotion)

    return f"""
You are a caring and emotionally intelligent support assistant.

Tone rule:
{tone}

User problem:
"{user_message}"

Reply rules:
- Acknowledge the problem
- Reassure the user
- Do NOT over-talk
- Do NOT give legal advice
- Sound human, not corporate
- Keep it supportive and practical
"""
