from enum import Enum


class IntentType(str, Enum):
    GREETING = "greeting"
    NORMAL_QUERY = "normal_query"     # DB-based queries like plan, recharge
    NORMAL_HELP = "normal_help"       # Goes to local LLM
    CRITICAL = "critical"             # Goes to premium LLM
    NON_IMPORTANT = "non_important"   # hmm, ok, yes, etc.


class RouteType(str, Enum):
    NORMAL = "normal"
    LOCAL_LLM = "local_llm"
    PREMIUM_LLM = "premium_llm"
