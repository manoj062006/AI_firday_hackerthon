from pydantic import BaseModel, Field
from typing import Optional
from app.models.enums import RouteType


class ChatRequest(BaseModel):
    user_id: str = Field(..., description="Unique user identifier")
    message: str = Field(..., min_length=1)


class ChatResponse(BaseModel):
    user_id: str
    reply: str
    route_used: RouteType
