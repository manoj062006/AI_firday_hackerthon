from sqlalchemy import Column, Integer, String
from app.db.session import Base


class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, index=True)
    name = Column(String)


class Plan(Base):
    __tablename__ = "plans"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(String, index=True)
    plan_name = Column(String)
    benefits = Column(String)
    data_balance = Column(String)
    validity_end = Column(String)


class Recharge(Base):
    __tablename__ = "recharges"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(String, index=True)
    amount = Column(String)
    last_recharge_date = Column(String)
