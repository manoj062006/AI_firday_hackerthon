from sqlalchemy.orm import Session
from app.db import models


def get_user_plan(db: Session, user_id: str):
    return db.query(models.Plan).filter(models.Plan.user_id == user_id).first()


def get_user_recharge(db: Session, user_id: str):
    return db.query(models.Recharge).filter(models.Recharge.user_id == user_id).first()
