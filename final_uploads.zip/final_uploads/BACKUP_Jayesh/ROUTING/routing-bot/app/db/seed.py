from app.db.session import SessionLocal
from app.db import models

def seed():
    db = SessionLocal()

    # Simple demo user
    user = models.User(
        id="u1",
        name="Demo User"
    )

    plan = models.Plan(
        user_id="u1",
        plan_name="₹299 Unlimited",
        benefits="Unlimited calls, 2GB/day, 100 SMS/day",
        data_balance="1.3 GB remaining today",
        validity_end="2025-12-10"
    )

    recharge = models.Recharge(
        user_id="u1",
        amount="299",
        last_recharge_date="2025-11-10"
    )

    db.add(user)
    db.add(plan)
    db.add(recharge)
    db.commit()
    db.close()
    print("✅ Seed data inserted for user_id='u1'")


if __name__ == "__main__":
    seed()
