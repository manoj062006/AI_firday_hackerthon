import os
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Premium LLM (Cloud) configuration
PREMIUM_LLM_API_KEY = os.getenv("PREMIUM_LLM_API_KEY", "sk-QIOxO8UXL369Fc6SBzAPPw")
PREMIUM_LLM_BASE_URL = os.getenv("PREMIUM_LLM_BASE_URL", "https://genailab.tcs.in")  # e.g. your Azure/OpenRouter base URL
PREMIUM_LLM_MODEL = os.getenv("PREMIUM_LLM_MODEL", "gemini-2.5-pro")  # your chosen model name
