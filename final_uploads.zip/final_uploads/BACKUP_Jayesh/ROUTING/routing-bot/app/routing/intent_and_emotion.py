import re
from enum import Enum


# -----------------------------
# INTENT TYPES
# -----------------------------
class IntentType(str, Enum):
    GREETING = "greeting"
    DB_QUERY = "db_query"          # plan, data, validity, benefits
    SIMPLE_HELP = "simple_help"   # how-to, feature help (local LLM)
    FAILURE = "failure"           # recharge failed, payment failed, app not working
    OTHER = "other"


# -----------------------------
# EMOTION TYPES
# -----------------------------
class EmotionType(str, Enum):
    ANGRY = "angry"
    FRUSTRATED = "frustrated"
    CONFUSED = "confused"
    HAPPY = "happy"
    NEUTRAL = "neutral"


# -----------------------------
# GREETING DETECTOR
# -----------------------------
def is_greeting(text: str) -> bool:
    greetings = [
        "hi", "hello", "hey", "good morning",
        "good evening", "good afternoon"
    ]
    text = text.lower().strip()
    return text in greetings


# -----------------------------
# FAILURE / PROBLEM DETECTOR (PREMIUM LLM)
# -----------------------------
def is_failure(text: str) -> bool:
    failure_phrases = [
        "recharge failed",
        "payment failed",
        "money deducted",
        "charged twice",
        "app not working",
        "not working",
        "transaction failed",
        "refund",
        "scam",
        "fraud",
        "complaint",
        "problem",
        "issue"
    ]
    text = text.lower()
    return any(p in text for p in failure_phrases)


# -----------------------------
# DB QUERY DETECTOR (LOCAL LLM + DB)
# -----------------------------
def is_db_query(text: str) -> bool:
    db_phrases = [
        "my plan",
        "current plan",
        "plan details",
        "benefits",
        "data left",
        "data balance",
        "validity",
        "when will my recharge expire",
        "recharge expiry"
    ]
    text = text.lower()
    return any(p in text for p in db_phrases)


# -----------------------------
# SIMPLE HELP DETECTOR (LOCAL LLM)
# -----------------------------
def is_simple_help(text: str) -> bool:
    help_phrases = [
        "how to",
        "how can i",
        "help me",
        "guide me",
        "explain",
        "what is this feature",
    ]
    text = text.lower()
    return any(p in text for p in help_phrases)


# -----------------------------
# EMOTION DETECTOR
# -----------------------------
def detect_emotion(text: str) -> EmotionType:
    text = text.lower()

    if any(w in text for w in ["angry", "worst", "disgusting", "pathetic"]):
        return EmotionType.ANGRY

    if any(w in text for w in ["frustrated", "tired", "annoyed", "fed up"]):
        return EmotionType.FRUSTRATED

    if any(w in text for w in ["confused", "not sure", "don't understand"]):
        return EmotionType.CONFUSED

    if any(w in text for w in ["happy", "great", "awesome", "thanks", "thank you"]):
        return EmotionType.HAPPY

    return EmotionType.NEUTRAL


# -----------------------------
# MASTER CLASSIFIER
# -----------------------------
def classify_intent_and_emotion(user_message: str):
    """
    This is the ONLY function your router should call.
    """

    message = user_message.strip().lower()

    # 1. Greeting
    if is_greeting(message):
        return IntentType.GREETING, detect_emotion(message)

    # 2. Failures & problems → Premium LLM
    if is_failure(message):
        return IntentType.FAILURE, detect_emotion(message)

    # 3. DB queries → DB + Local LLM human reply
    if is_db_query(message):
        return IntentType.DB_QUERY, detect_emotion(message)

    # 4. Simple help → Local LLM
    if is_simple_help(message):
        return IntentType.SIMPLE_HELP, detect_emotion(message)

    # 5. Fallback
    return IntentType.OTHER, detect_emotion(message)
