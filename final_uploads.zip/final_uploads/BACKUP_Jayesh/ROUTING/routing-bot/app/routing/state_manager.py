from collections import defaultdict


_user_state = defaultdict(lambda: {
    "has_started_real_conversation": False
})


def has_conversation_started(user_id: str) -> bool:
    return _user_state[user_id]["has_started_real_conversation"]


def mark_conversation_started(user_id: str):
    _user_state[user_id]["has_started_real_conversation"] = True
