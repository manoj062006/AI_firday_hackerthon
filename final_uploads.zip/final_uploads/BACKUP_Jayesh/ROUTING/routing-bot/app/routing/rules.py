import re


GREETINGS = ["hi", "hello", "hey", "good morning", "good evening"]
USELESS = ["ok", "okay", "hmm", "hmmm", "yes", "no", "fine", "cool", "nice"]
DB_KEYWORDS = [
    "plan", "recharge", "validity", "data", "balance", "benefits",
    "expiry", "expires", "current plan"
]


def is_greeting(text: str) -> bool:
    text = text.lower()
    return any(greet in text for greet in GREETINGS)


def is_useless(text: str) -> bool:
    text = text.lower().strip()
    return text in USELESS


def is_db_query(text: str) -> bool:
    text = text.lower()
    return any(keyword in text for keyword in [
        "plan", "recharge", "validity", "data", "balance", "benefits",
        "expiry", "expires", "current plan"
    ])



def is_critical(text: str) -> bool:
    """
    Simple keyword-based critical detector.
    Later we can replace this with AI classification.
    """
    critical_keywords = [
        "fraud", "legal", "scam", "court", "complaint",
        "money deducted", "charged twice", "not resolved"
    ]
    text = text.lower()
    return any(k in text for k in critical_keywords)
