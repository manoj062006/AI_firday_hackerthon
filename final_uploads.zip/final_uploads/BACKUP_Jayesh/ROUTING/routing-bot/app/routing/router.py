from typing import Tuple
from app.routing.intent_and_emotion import (
    classify_intent_and_emotion,
    IntentType,
    EmotionType,
)
from app.models.enums import RouteType


def route_message(user_message: str) -> Tuple[RouteType, IntentType, EmotionType]:
    """
    Master router for the chatbot.

    Returns:
        - route_type: NORMAL / LOCAL_LLM / PREMIUM_LLM
        - intent: detected user intent
        - emotion: detected user emotion
    """

    intent, emotion = classify_intent_and_emotion(user_message)

    # ✅ 1. Greetings → Static (no LLM, no DB)
    if intent == IntentType.GREETING:
        return RouteType.NORMAL, intent, emotion

    # ✅ 2. DB Queries → DB + Local LLM (human reply)
    if intent == IntentType.DB_QUERY:
        return RouteType.LOCAL_LLM, intent, emotion

    # ✅ 3. Simple Help → Local LLM
    if intent == IntentType.SIMPLE_HELP:
        return RouteType.LOCAL_LLM, intent, emotion

    # ✅ 4. Failures & Problems → PREMIUM LLM
    if intent == IntentType.FAILURE:
        return RouteType.PREMIUM_LLM, intent, emotion

    # ✅ 5. Everything Else → Local LLM (safe fallback)
    return RouteType.LOCAL_LLM, intent, emotion
