const { useState, useEffect, useRef } = React;

const ChatMessage = ({ role, content, image }) => {
  if (role === "system") {
    return (
      <div className="flex justify-center my-2">
        <div className="bg-blue-50 border border-blue-200 text-blue-700 px-4 py-2 rounded-xl text-sm shadow-sm">
          {content}
        </div>
      </div>
    );
  }

  const isUser = role === "user";
  return (
    <div className={`flex w-full mb-4 ${isUser ? "justify-end" : "justify-start"} msg-enter`}>
      <div className={`flex max-w-[80%] ${isUser ? "flex-row-reverse" : "flex-row"} items-end gap-3`}>
        <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold shrink-0
          ${isUser ? "bg-indigo-600 text-white" : "bg-emerald-500 text-white"}`}>
          {isUser ? "YOU" : "AI"}
        </div>

        <div className={`p-3 rounded-2xl shadow-sm text-sm leading-relaxed
          ${isUser ? "bg-indigo-600 text-white rounded-br-none" : "bg-white text-gray-800 rounded-bl-none border border-gray-100"}`}>
          
          <div>{content}</div>

          {image && (
            <div className="mt-2">
              <img src={image} className="max-w-xs rounded-md border" alt="attachment preview"/>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const App = () => {
  const [messages, setMessages] = useState([
    { role: "model", content: "Hello! I'm Sarah from TeleConnect Support. How can I help today?" }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [attachedFile, setAttachedFile] = useState(null);
  const [attachedPreview, setAttachedPreview] = useState(null);
  const [sessionId] = useState(() => "session_" + Math.random().toString(36).slice(2, 9));
  const messagesEndRef = useRef(null);

  const fileInputRef = useRef();

  useEffect(() => {
    setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }), 60);
  }, [messages, isTyping]);

  const onPickImage = () => fileInputRef.current?.click();

  const onFileChange = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;

    setAttachedFile(f);
    const url = URL.createObjectURL(f);
    setAttachedPreview(url);
  };

  const removeAttachment = () => {
    setAttachedFile(null);
    if (attachedPreview) URL.revokeObjectURL(attachedPreview);
    setAttachedPreview(null);
    fileInputRef.current.value = null;
  };

  const CHUNK_RECAP_MARKER = "CONTEXT SUMMARY";

  const sendMessage = async () => {
    if (!input.trim() && !attachedFile) return;

    const userText = input;
    setMessages(prev => [...prev, { role: "user", content: userText || "(image)", image: attachedPreview }]);
    setInput("");
    setIsTyping(true);

    try {
      let response;

      if (attachedFile) {
        const fd = new FormData();
        fd.append("message", userText);
        fd.append("sessionId", sessionId);
        fd.append("image", attachedFile, attachedFile.name);

        response = await fetch("http://localhost:5000/api/chat", {
          method: "POST",
          body: fd
        });
      } else {
        response = await fetch("http://localhost:5000/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: userText, sessionId })
        });
      }

      if (!response.body) {
        const text = await response.text();
        setMessages(prev => [...prev, { role: "model", content: text }]);
        setIsTyping(false);
        removeAttachment();
        return;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      setMessages(prev => [...prev, { role: "model", content: "" }]);

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });

        if (chunk.includes(CHUNK_RECAP_MARKER)) {
          setMessages(prev => [...prev, { role: "system", content: "I've summarized our earlier conversation for continuity." }]);
        }

        setMessages(prev => {
          const copy = [...prev];
          const idx = copy.findIndex(m => m.role === "model" && m.content === "");
          if (idx !== -1) {
            copy[idx].content = chunk;
          } else {
            const last = copy.length - 1;
            if (copy[last].role === "model") {
              copy[last].content += chunk;
            }
          }
          return copy;
        });

        await new Promise(r => setTimeout(r, 5));
      }
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: "system", content: "⚠️ Network error." }]);
    }

    setIsTyping(false);
    removeAttachment();
  };

  return window.renderChat(App, {
    sendMessage,
    input,
    setInput,
    isTyping,
    onPickImage,
    fileInputRef,
    attachedPreview,
    removeAttachment,
    messages,
    messagesEndRef,
    onKeyDown: (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }
  });
};

window.onload = () => {
  ReactDOM.createRoot(document.getElementById("root")).render(<App />);
};
