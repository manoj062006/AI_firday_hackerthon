import os
import time
import json
import re
import uuid
import base64
import traceback
from flask import Flask, request, jsonify, Response, stream_with_context, g, has_request_context
from flask_cors import CORS
from dotenv import load_dotenv

# LLM imports
from langchain_openai import ChatOpenAI
import httpx

# Internal modules
from knowledge_base import search_knowledge_base
from telecom_db import get_user_plan_info, authenticate_user

# Token counter
try:
    import tiktoken
except:
    tiktoken = None

# Logging
import logging
from logging.handlers import RotatingFileHandler

load_dotenv()

app = Flask(__name__)
CORS(app)

# ---------------------------------------------------------
# Logging
# ---------------------------------------------------------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_FILE = os.getenv("LOG_FILE", "app.log")

logger = logging.getLogger("teleconnect")
logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))

handler = RotatingFileHandler(LOG_FILE, maxBytes=5_242_880, backupCount=5)
formatter = logging.Formatter(
    fmt="%(asctime)s %(levelname)s [%(request_id)s] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S"
)
handler.setFormatter(formatter)
logger.addHandler(handler)

console = logging.StreamHandler()
console.setFormatter(formatter)
logger.addHandler(console)

class RequestIdFilter(logging.Filter):
    def filter(self, record):
        if has_request_context():
            record.request_id = getattr(g, "request_id", "-")
        else:
            record.request_id = "startup"
        return True

logger.addFilter(RequestIdFilter())

# ---------------------------------------------------------
# LLM Client
# ---------------------------------------------------------
HTTPX_CLIENT = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url=os.getenv("LLM_BASE_URL", "https://genailab.tcs.in"),
    model=os.getenv("LLM_MODEL", "gemini-2.5-flash"),
    api_key=os.getenv("LLM_API_KEY", "sk-QIOxO8UXL369Fc6SBzAPPw"),
    http_client=HTTPX_CLIENT,
)

# ---------------------------------------------------------
# Tokens
# ---------------------------------------------------------
def count_tokens(text: str) -> int:
    if not text:
        return 0
    try:
        if tiktoken:
            enc = tiktoken.get_encoding("cl100k_base")
            return len(enc.encode(text))
    except:
        pass
    return len(text) // 3

TOKEN_LIMIT_HARD = int(os.getenv("TOKEN_LIMIT_HARD", 500))

# ---------------------------------------------------------
# System persona
# ---------------------------------------------------------
SYSTEM_INSTRUCTION = """
You are Sarah, a professional Customer Support Agent for TeleConnect.
- Answer in 2–3 sentences unless detailed steps are required.
- Always be empathetic.
- Use bullet points when listing steps or plan features.
- Private customer information must only be disclosed to the authenticated customer currently logged in/chatting to you.
"""

# ---------------------------------------------------------
# Session storage
# ---------------------------------------------------------
sessions = {}

def get_chat_session(session_id):
    if session_id not in sessions:
        sessions[session_id] = []
    return sessions[session_id]

def update_session(session_id, role, content):
    sessions[session_id].append({
        "role": "assistant" if role == "model" else role,
        "content": content
    })
    if len(sessions[session_id]) > 20:
        sessions[session_id] = sessions[session_id][-20:]

# ---------------------------------------------------------
# Middleware
# ---------------------------------------------------------
@app.before_request
def before():
    g.request_id = str(uuid.uuid4())[:8]
    g.request_start = time.time()
    try:
        logger.info(f"Incoming {request.method} {request.path} payload={request.get_json(silent=True)}")
    except:
        logger.info(f"Incoming {request.method} {request.path}")

@app.after_request
def after(response):
    duration = time.time() - g.request_start
    logger.info(f"Completed in {duration:.3f}s")
    response.headers["X-Request-ID"] = g.request_id
    return response

# ---------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------
def build_prompt(user_message, history, kb_context, user_context, images_attached=False):
    system_summary = ""
    if history and len(history) > 0 and history[0].get("role") == "system":
        system_summary = history[0]["content"]

    hist_lines = []
    for msg in history:
        if msg["role"] == "system":
            continue
        role = msg["role"].upper()
        hist_lines.append(f"{role}: {msg['content']}")

    prompt_parts = [
        SYSTEM_INSTRUCTION.strip(),
    ]

    if system_summary:
        prompt_parts.append(system_summary)

    if kb_context:
        prompt_parts.append("KNOWLEDGE_BASE:\n" + kb_context)

    if user_context:
        prompt_parts.append("USER_ACCOUNT_CONTEXT:\n" + user_context)

    if images_attached:
        prompt_parts.append("NOTE: User uploaded images. Perform OCR, analyze objects, errors, model numbers, defects.")

    if hist_lines:
        prompt_parts.append("RECENT CONVERSATION:\n" + "\n".join(hist_lines))

    prompt_parts.append("USER QUERY:\n" + user_message)

    return "\n\n".join(prompt_parts)

# ---------------------------------------------------------
# Login (username + password)
# ---------------------------------------------------------
@app.post("/api/login")
def login():
    data = request.json or {}
    username = data.get("username", "").strip()
    password = data.get("password", "").strip()

    user = authenticate_user(username, password)
    if not user:
        return jsonify({"success": False, "error": "Invalid credentials"}), 401

    return jsonify({
        "success": True,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "name": user["name"]
        }
    })

# ---------------------------------------------------------
# Chat endpoint
# ---------------------------------------------------------
@app.post("/api/chat")
def chat():
    image_files = []
    images_base64 = []

    # Multipart = images
    if request.content_type and request.content_type.startswith("multipart/form-data"):
        user_message = request.form.get("message", "").strip()
        session_id = request.form.get("sessionId", "default_session")
        image_files = request.files.getlist("images")
    else:
        data = request.json or {}
        user_message = (data.get("message") or "").strip()
        session_id = data.get("sessionId", "default_session")

    if not user_message and not image_files:
        return jsonify({"error": "Empty message"}), 400

    history = get_chat_session(session_id)

    # --- RAG search ---
    kb_context = search_knowledge_base(user_message)

    # --- user context ---
    user_context = ""
    uid_match = re.search(r"\b(U\d{3})\b", user_message, re.I)
    if uid_match:
        info = get_user_plan_info(uid_match.group(1).upper())
        if info:
            user = info["user"]
            plan = info["plan"]
            user_context = (
                f"Name: {user['name']}\n"
                f"Plan: {plan['name']} ({plan.get('speed')})\n"
                f"Status: {user['account_status']}\n"
                f"Usage: {user['data_usage_gb']}GB / {user['data_limit_gb']}\n"
                f"Bill: ₹{user['bill_amount']}\n"
            )

    # --- Process images ---
    for img in image_files:
        try:
            raw = img.read()
            b64 = base64.b64encode(raw).decode("utf-8")
            mime = "image/jpeg"
            fname = img.filename.lower()
            if fname.endswith(".png"): mime = "image/png"
            if fname.endswith(".webp"): mime = "image/webp"

            images_base64.append(f"data:{mime};base64,{b64}")
        except Exception as e:
            logger.warning(f"Failed image decode: {e}")

    # --- Build prompt ---
    prompt = build_prompt(user_message, history, kb_context, user_context, images_attached=bool(images_base64))

    # --- Token-limit check ---
    token_count = count_tokens(prompt)
    logger.info(f"Token count = {token_count}")

    # --- Recap if over limit ---
    if token_count > TOKEN_LIMIT_HARD:
        logger.info("Token limit exceeded — recap triggered")

        messages_for_recap = []
        for msg in history:
            if msg["role"] != "system":
                messages_for_recap.append({
                    "sender": "bot" if msg["role"] == "assistant" else "user",
                    "text": msg["content"]
                })
        messages_for_recap.append({"sender": "user", "text": user_message})

        convo_json = {
            "conversation_id": session_id,
            "messages": messages_for_recap
        }

        recap_prompt = f"""
You summarize support chats.

Input JSON:
{json.dumps(convo_json, ensure_ascii=False)}

Return EXACTLY this JSON format:
{{
 "conversation_id": "...",
 "summary": [
   "bullet 1",
   "bullet 2",
   "bullet 3",
   "bullet 4",
   "bullet 5"
 ]
}}
"""

        recap = llm.invoke(recap_prompt)
        recap_raw = recap.content

        try:
            recap_json = json.loads(re.findall(r"\{.*\}", recap_raw, re.S)[0])
            summary = "\n".join([f"- {s}" for s in recap_json["summary"]])
            sessions[session_id] = [{
                "role": "system",
                "content": "CONTEXT SUMMARY:\n" + summary,
                "sent": False
            }]
            history = sessions[session_id]
            prompt = build_prompt(user_message, history, kb_context, user_context, images_attached=bool(images_base64))
        except:
            logger.error("Recap JSON parse failed, continuing without recap.")

    # ---------------------------------------------------------
    # Streaming generator
    # ---------------------------------------------------------
    def stream():
        try:
            # Send recap once
            if history and history[0].get("role") == "system" and not history[0].get("sent"):
                yield history[0]["content"] + "\n\n"
                history[0]["sent"] = True

            # Build multimodal LLM input
            if images_base64:
                content = [{"type": "text", "text": prompt}]
                for b64img in images_base64:
                    content.append({"type": "input_image", "image_url": b64img})

                input_payload = [{"role": "user", "content": content}]
                resp = llm.invoke(input_payload)
            else:
                resp = llm.invoke(prompt)

            text = resp.content.strip()

            # Stream chunked
            chunk_size = 80
            for i in range(0, len(text), chunk_size):
                yield text[i:i+chunk_size]
                time.sleep(0.02)

            update_session(session_id, "user", user_message)
            update_session(session_id, "model", text)

        except Exception as e:
            logger.error(f"Streaming error: {e}")
            fallback = "Sorry, I’m having technical issues."
            yield fallback
            update_session(session_id, "model", fallback)

    return Response(stream_with_context(stream()), mimetype="text/plain")

# ---------------------------------------------------------
# Analyzer endpoint
# ---------------------------------------------------------
from pydantic import BaseModel
from typing import List, Literal, Optional
import regex as regex_mod

class Msg(BaseModel):
    sender: Literal["user", "bot"]
    text: str

class ConversationRequest(BaseModel):
    conversation_id: Optional[str]
    messages: List[Msg]

def extract_json(text):
    m = regex_mod.search(r"\{.*\}", text, regex_mod.S)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except:
        return None

@app.post("/analyze")
def analyze_conversation(payload: ConversationRequest):
    try:
        user_text = " ".join([m.text for m in payload.messages if m.sender == "user"])
        full_conv = "\n".join([f"{m.sender}: {m.text}" for m in payload.messages])

        # Sentiment
        sent_prompt = f"""
You are a sentiment classifier.
Return ONLY JSON: {{"score": -100 to 100}}.
Customer: \"\"\"{user_text}\"\"\"
"""
        sent = llm.invoke(sent_prompt)
        sent_raw = sent.content
        sent_json = extract_json(sent_raw) or {"score": 0}
        score = int(sent_json.get("score", 0))
        label = "POSITIVE" if score > 20 else "NEGATIVE" if score < -20 else "NEUTRAL"

        # Summary
        sum_prompt = f"Summarize in 2-3 sentences:\n{full_conv}"
        sum_resp = llm.invoke(sum_prompt)
        summary_text = sum_resp.content.strip()

        # Outcome
        kb_prompt = f"""
Extract ONLY final outcomes.
Return JSON:
{{
 "Information_bucket": ["item1","item2"]
}}
Conversation:
{full_conv}
"""
        kb_resp = llm.invoke(kb_prompt)
        kb_raw = kb_resp.content
        kb_json = extract_json(kb_raw) or {"Information_bucket": []}

        return {
            "conversation_id": payload.conversation_id,
            "summary": summary_text,
            "customer_sentiment": {"label": label, "score": score},
            "Information_bucket": kb_json["Information_bucket"],
            "escalation_required": score <= -60,
            "task_type": "COMPLEX" if score < -20 else "SIMPLE",
            "db_change_required": False,
            "routing_source": "RULES"
        }

    except Exception as e:
        return {"error": str(e)}

# ---------------------------------------------------------
# Run
# ---------------------------------------------------------
if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    logger.info(f"Starting Flask on {port}")
    app.run(debug=(LOG_LEVEL == "DEBUG"), host="0.0.0.0", port=port)
