
# Mock Knowledge Base - SOPs and Policies

KNOWLEDGE_BASE = {
    "refund_policy": """
    **Refund Policy**
    - **Eligibility**: Refunds are available for subscription purchases within 14 days of the initial transaction.
    - **Third-Party Purchases**: If the subscription was purchased through a third-party (e.g., App Store, Google Play), the refund must be requested through that platform directly. We cannot process these refunds.
    - **Processing Time**: Approved refunds typically take 5-10 business days to appear on your statement.
    - **Exceptions**: No refunds for partial months or unused services after the 14-day window.
    """,

    "technical_support": """
    **Technical Support Guide**
    - **Login Issues**: Ensure caps lock is off. If password is forgotten, use the 'Forgot Password' link.
    - **App Crashing**: Try clearing the cache and data. If the issue persists, reinstall the application.
    - **Slow Performance**: Check your internet connection. A minimum of 10Mbps is recommended.
    """,

    "account_management": """
    **Account Management**
    - **Change Email**: Go to Settings > Account > Email to update your registered email address.
    - **Delete Account**: This action is permanent. Go to Settings > Privacy > Delete Account. You will have 30 days to recover it before permanent deletion.
    """
}

def search_knowledge_base(query):
    """
    Simple keyword-based search to simulate RAG.
    """
    query = query.lower()
    results = []
    
    # Simple keyword matching
    if "refund" in query or "money back" in query:
        results.append(KNOWLEDGE_BASE["refund_policy"])
    if "login" in query or "crash" in query or "slow" in query or "technical" in query:
        results.append(KNOWLEDGE_BASE["technical_support"])
    if "email" in query or "delete account" in query or "account" in query:
        results.append(KNOWLEDGE_BASE["account_management"])
        
    return "\n\n".join(results) if results else ""
