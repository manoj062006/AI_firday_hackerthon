# backend/app.py
import os
import time
import json
import re
import uuid
import traceback
from flask import Flask, request, jsonify, Response, stream_with_context, g, has_request_context
from flask_cors import CORS
from dotenv import load_dotenv

# LLM imports
from langchain_openai import ChatOpenAI
import httpx

# Internal modules (unchanged)
from knowledge_base import search_knowledge_base
from telecom_db import get_user_plan_info, authenticate_user

# Token counting (try tiktoken, fallback heuristic)
try:
    import tiktoken
except Exception:
    tiktoken = None

# Logging
import logging
from logging.handlers import RotatingFileHandler

# Load environment
load_dotenv()

app = Flask(__name__)
CORS(app)

# ---------------------------
# Logging setup (Windows-safe: no emoji outputs)
# ---------------------------
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
LOG_FILE = os.getenv("LOG_FILE", "app.log")

logger = logging.getLogger("teleconnect")
logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))

handler = RotatingFileHandler(LOG_FILE, maxBytes=5_242_880, backupCount=5)
formatter = logging.Formatter(fmt="%(asctime)s %(levelname)s [%(request_id)s] %(message)s",
                              datefmt="%Y-%m-%dT%H:%M:%S")
handler.setFormatter(formatter)
logger.addHandler(handler)

ch = logging.StreamHandler()
ch.setFormatter(formatter)
logger.addHandler(ch)

class RequestIdFilter(logging.Filter):
    def filter(self, record):
        # safe check for request context
        if has_request_context():
            record.request_id = getattr(g, "request_id", "-")
        else:
            record.request_id = "startup"
        return True

logger.addFilter(RequestIdFilter())

# ---------------------------
# LLM client config
# ---------------------------
HTTPX_CLIENT = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url=os.getenv("LLM_BASE_URL", "https://genailab.tcs.in"),
    model=os.getenv("LLM_MODEL", "gemini-2.5-flash"),
    api_key=os.getenv("LLM_API_KEY", "sk-QIOxO8UXL369Fc6SBzAPPw"),
    http_client=HTTPX_CLIENT,
)

# ---------------------------
# Token utilities & limits
# ---------------------------
def count_tokens(text: str) -> int:
    if not text:
        return 0
    try:
        if tiktoken:
            enc = tiktoken.get_encoding("cl100k_base")
            return len(enc.encode(text))
    except Exception:
        pass
    return max(1, len(text) // 3)

TOKEN_LIMIT_HARD = int(os.getenv("TOKEN_LIMIT_HARD", 600))

# ---------------------------
# System instruction (model persona)
# ---------------------------
SYSTEM_INSTRUCTION = """
You are "Sarah", a professional Customer Support Agent for TeleConnect.

Guidelines:
- Helpful, concise, 2–3 sentences unless detailed steps are needed.
- Show empathy.
- Use bullet points for steps or features.
- Never reveal other customers’ personal data.
"""

# ---------------------------
# In-memory sessions
# ---------------------------
sessions = {}

def get_chat_session(session_id):
    if session_id not in sessions:
        sessions[session_id] = []
    return sessions[session_id]

def update_session(session_id, role, content):
    sessions[session_id].append({
        "role": "assistant" if role == "model" else role,
        "content": content
    })
    # sliding window
    if len(sessions[session_id]) > 20:
        sessions[session_id] = sessions[session_id][-20:]

# ---------------------------
# Request ID middleware
# ---------------------------
@app.before_request
def before_req():
    g.request_id = str(uuid.uuid4())[:8]
    g.request_start = time.time()
    try:
        logger.info(f"Incoming {request.method} {request.path} payload={request.get_json(silent=True)}")
    except Exception:
        logger.info(f"Incoming {request.method} {request.path}")

@app.after_request
def after_req(response):
    duration = time.time() - getattr(g, "request_start", time.time())
    logger.info(f"Request completed in {duration:.3f}s")
    response.headers["X-Request-ID"] = g.request_id
    return response

# ---------------------------
# Prompt builder (excludes system role from dialogue history)
# ---------------------------
def build_prompt(user_message, history, kb_context, user_context):
    # Extract system_summary (if present) but do not place it in conversation history
    system_summary = ""
    if history and isinstance(history, list) and len(history) > 0:
        first = history[0]
        if isinstance(first, dict) and first.get("role") == "system":
            system_summary = first.get("content", "")

    # Build conversation history excluding system entries
    history_lines = []
    if history:
        for msg in history:
            if msg.get("role") == "system":
                continue
            role_label = msg.get("role", "").upper()
            text = msg.get("content", "")
            history_lines.append(f"{role_label}: {text}")
    history_block = "\n".join(history_lines).strip()

    parts = []
    # System instruction
    parts.append(SYSTEM_INSTRUCTION.strip())
    # Add system summary/context if present
    if system_summary:
        parts.append(system_summary.strip())
    # Add KB context and user context
    if kb_context:
        parts.append("KNOWLEDGE_BASE:\n" + kb_context)
    if user_context:
        parts.append("USER_ACCOUNT_CONTEXT:\n" + user_context)
    # Add recent conversation
    if history_block:
        parts.append("RECENT CONVERSATION:\n" + history_block)
    # Add user query
    parts.append("USER QUERY:\n" + user_message)
    final_prompt = "\n\n".join(parts)
    return final_prompt

# ---------------------------
# Health endpoint
# ---------------------------
@app.route("/api/health", methods=["GET"])
def health():
    llm_ok = False
    llm_latency = None
    try:
        start = time.time()
        resp = llm.invoke("pong")
        llm_latency = time.time() - start
        llm_ok = True
    except Exception as e:
        logger.warning(f"LLM health check failed: {e}")
        llm_ok = False
    return jsonify({
        "status": "ok",
        "llm": "reachable" if llm_ok else "unreachable",
        "llm_latency_s": round(llm_latency, 3) if llm_latency else None,
        "active_sessions": len(sessions)
    })

# ---------------------------
# Streaming chat endpoint
# ---------------------------
@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json or {}
    user_message = data.get("message", "").strip()
    session_id = data.get("sessionId", "default_session")

    if not user_message:
        return jsonify({"error": "Message is required"}), 400

    history = get_chat_session(session_id)

    # RAG: KB search
    kb_context = search_knowledge_base(user_message)

    # User account context (if user id present)
    user_context = ""
    user_id_match = re.search(r'\b(U\d{3})\b', user_message, re.IGNORECASE)
    if user_id_match:
        uid = user_id_match.group(1).upper()
        info = get_user_plan_info(uid)
        if info:
            user = info.get("user", {})
            plan = info.get("plan", {})
            user_context = (
                f"Name: {user.get('name')}\n"
                f"User ID: {user.get('id')}\n"
                f"Phone: {user.get('phone')}\n"
                f"Account Status: {user.get('account_status')}\n"
                f"Current Plan: {plan.get('name')} ({plan.get('speed', 'N/A')})\n"
                f"Data Usage: {user.get('data_usage_gb')} GB / {user.get('data_limit_gb')}\n"
                f"Monthly Bill: ₹{user.get('bill_amount')}\n"
            )

    # Build prompt (system summary included automatically if present in history)
    prompt = build_prompt(user_message, history, kb_context, user_context)

    # Token count and recap check
    token_count = count_tokens(prompt)
    logger.info(f"Token estimate for prompt: {token_count} tokens (limit {TOKEN_LIMIT_HARD})")

    if token_count > TOKEN_LIMIT_HARD:
        logger.info("Token limit exceeded - running recap")
        try:
            # Prepare conversation JSON for summarizer
            # Build messages array from history + latest user message appended
            messages_for_recap = []
            # Convert our history into messages array (skip existing system summaries)
            for msg in history:
                if msg.get("role") == "system":
                    continue
                messages_for_recap.append({
                    "sender": "bot" if msg.get("role") == "assistant" else msg.get("role"),
                    "text": msg.get("content")
                })
            # Append the new user turn
            messages_for_recap.append({"sender": "user", "text": user_message})

            conversation_json = {
                "conversation_id": session_id,
                "messages": messages_for_recap
            }

            # Use the strict summarizer prompt (exact JSON in / analyze approach)
            summarizer_prompt = f"""
You are a conversation summarizer for a telecom customer support system.

You will receive a JSON object containing:
{json.dumps(conversation_json, ensure_ascii=False)}

STRICT OUTPUT RULES:
1. Output must be VALID JSON.
2. Keep the same "conversation_id".
3. Produce EXACTLY 5 bullet points inside an array named "summary".
4. Each bullet must describe: the user's issue/request, what the agent analyzed/explained, actions the agent took, troubleshooting steps, and final resolution/status.
5. Do NOT include any extra text outside the JSON.
6. Output ONLY the JSON object.
"""

            recap_resp = llm.invoke(summarizer_prompt)
            recap_text_raw = getattr(recap_resp, "content", "") or str(recap_resp).strip()
            # Try to parse JSON out of model output (expecting a strict JSON object)
            recap_json = None
            try:
                recap_json = json.loads(recap_text_raw)
            except Exception:
                # try to extract JSON substring
                m = re.search(r'\{.*\}', recap_text_raw, re.DOTALL)
                if m:
                    try:
                        recap_json = json.loads(m.group(0))
                    except Exception:
                        recap_json = None

            if recap_json and "summary" in recap_json:
                recap_summary = recap_json["summary"]
                # store recap as system role (context), not assistant text
                sessions[session_id] = [{
                    "role": "system",
                    "content": "CONTEXT SUMMARY:\n" + "\n".join([f"- {s}" for s in recap_summary]),
                    "sent": False
                }]
                history = sessions[session_id]
                # rebuild prompt with new system summary
                prompt = build_prompt(user_message, history, kb_context, user_context)
                logger.info("Recap generated and stored as system context")
            else:
                logger.warning("Recap generation returned invalid JSON — skipping recap storage")
        except Exception as e:
            logger.error(f"Recap generation failed: {e}\n{traceback.format_exc()}")

    # Streaming generator
    def stream():
        try:
            # 1) If a system recap exists and hasn't been sent to user, send it first (only to UI)
            if history and isinstance(history, list) and len(history) > 0:
                first = history[0]
                if isinstance(first, dict) and first.get("role") == "system" and not first.get("sent"):
                    # send the human-friendly recap summary string
                    yield first.get("content", "").strip() + "\n\n"
                    # mark as sent so it won't be sent again
                    history[0]["sent"] = True

            # 2) Call LLM with prompt (prompt already excludes system from chat history but includes system summary as context)
            start_llm = time.time()
            resp = llm.invoke(prompt)
            llm_latency = time.time() - start_llm
            logger.info(f"LLM response time: {llm_latency:.3f}s")

            text = getattr(resp, "content", "") or str(resp).strip()
            # Stream text in chunks
            chunk_size = int(os.getenv("STREAM_CHUNK_SIZE", 80))
            for i in range(0, len(text), chunk_size):
                yield text[i:i+chunk_size]
                time.sleep(float(os.getenv("STREAM_DELAY_S", 0.03)))

            # Update session AFTER whole response streamed
            update_session(session_id, "user", user_message)
            update_session(session_id, "model", text)

        except Exception as e:
            logger.error(f"LLM error: {e}\n{traceback.format_exc()}")
            fallback = "I'm sorry, I'm having technical issues. Please try again."
            yield fallback
            update_session(session_id, "model", fallback)

    return Response(stream_with_context(stream()), mimetype="text/plain")

# ---------------------------
# Analyzer endpoint - structured analysis (from original analyze logic)
# ---------------------------
from pydantic import BaseModel
from typing import List, Literal, Optional
import regex as re  # using regex (imported here again to ensure availability)

class Message(BaseModel):
    sender: Literal["user", "bot"]
    text: str

class ConversationRequest(BaseModel):
    conversation_id: Optional[str] = None
    messages: List[Message]

def extract_json(text: str):
    """
    Extract the first JSON object found in a string.
    Returns a dict or None.
    """
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return None
    try:
        return json.loads(match.group(0))
    except:
        return None

@app.post("/analyze")
def analyze_conversation(payload: ConversationRequest):
    sentiment = {"label": "NEUTRAL", "score": 0}
    Information_bucket = []
    try:
        # Combine only USER messages
        customer_text = " ".join([m.text for m in payload.messages if m.sender == "user"]).strip()
        # Combine full conversation
        full_conversation = "\n".join([f"{m.sender.upper()}: {m.text}" for m in payload.messages]).strip()

        # ---------- SENTIMENT ----------
        if customer_text:
            sentiment_prompt = f"""
You are a sentiment scoring engine.
Return ONLY valid JSON:
{{"score": -100 to +100}}
Rules:
- -100 = extremely negative
- 0 = neutral
- +100 = extremely positive
Customer text:
\"\"\"{customer_text}\"\"\"
"""
            sentiment_response = llm.invoke(sentiment_prompt)
            sentiment_raw = getattr(sentiment_response, "content", "").strip()
            parsed = extract_json(sentiment_raw)
            if parsed and "score" in parsed:
                try:
                    score = int(parsed["score"])
                except:
                    score = 0
                if score < -20:
                    label = "NEGATIVE"
                elif score > 20:
                    label = "POSITIVE"
                else:
                    label = "NEUTRAL"
                sentiment = {"label": label, "score": score}

        # ---------- SUMMARY ----------
        summary_prompt = f"""
Summarize the following customer support conversation in 2–3 clear sentences:
Conversation:
{full_conversation}
"""
        summary_response = llm.invoke(summary_prompt)
        summary_text = getattr(summary_response, "content", "").strip()

        # ---------- KEY POINTS (OUTCOMES) ----------
        keypoints_prompt = f"""
Extract ONLY the final OUTCOME, SOLUTION, or CONCLUSION from the following customer support conversation.
STRICT RULES:
- Do NOT include complaints or emotions
- Do NOT include intermediate troubleshooting
- ONLY include final decisions, promises, actions, or resolutions
- Return 2 to 3 bullet points MAX
Return ONLY valid JSON in this exact format:
{{
  "Information_bucket": [
    "final outcome 1",
    "final outcome 2"
  ]
}}
Conversation:
{full_conversation}
"""
        keypoints_response = llm.invoke(keypoints_prompt)
        keypoints_raw = getattr(keypoints_response, "content", "").strip()
        keypoints_parsed = extract_json(keypoints_raw)
        if keypoints_parsed and "Information_bucket" in keypoints_parsed:
            Information_bucket = keypoints_parsed["Information_bucket"]

        # -------- RULE-BASED ROUTING (FAST PATH) --------
        task_type = "SIMPLE"
        db_change_required = False
        routing_source = "RULES"
        routing_keywords = [
            "refund", "technician", "appointment", "visit",
            "complaint", "dispute", "deducted", "failed",
            "reversed", "compensation", "switch", "legal",
            "cancel", "update", "address", "subscription"
        ]
        combined_rule_text = " ".join(Information_bucket).lower() + " " + full_conversation.lower()
        for word in routing_keywords:
            if word in combined_rule_text:
                task_type = "COMPLEX"
                db_change_required = True
                break

        # -------- LLM ROUTING VALIDATION (SMART LAYER) --------
        routing_prompt = f"""
You are a customer support workflow classifier.
Decide:
1. Is this a SIMPLE task or a COMPLEX task?
2. Does this require a backend DATABASE change?
Definitions:
- SIMPLE: informational, FAQ, status check, no backend update needed
- COMPLEX: refund, appointment, technician, complaint, cancellation, update, dispute
Return ONLY valid JSON in this format:
{{
  "task_type": "SIMPLE | COMPLEX",
  "db_change_required": true | false
}}
Conversation:
{full_conversation}
"""
        routing_response = llm.invoke(routing_prompt)
        routing_raw = getattr(routing_response, "content", "").strip()
        routing_parsed = extract_json(routing_raw)
        if routing_parsed and "task_type" in routing_parsed and "db_change_required" in routing_parsed:
            llm_task = routing_parsed["task_type"]
            llm_db_flag = bool(routing_parsed["db_change_required"])
            # If LLM disagrees with rules → mark as HYBRID and accept LLM
            if llm_task != task_type or llm_db_flag != db_change_required:
                task_type = llm_task
                db_change_required = llm_db_flag
                routing_source = "HYBRID"

        # -------- AUTO ESCALATION LOGIC --------
        escalation_required = False
        if sentiment["score"] <= -60:
            escalation_required = True
        critical_keywords = ["technician", "refund", "complaint", "switch", "legal", "escalate"]
        for point in Information_bucket:
            for word in critical_keywords:
                if word.lower() in point.lower():
                    escalation_required = True
                    break

        # ✅ FINAL SAFE RETURN
        return {
            "conversation_id": payload.conversation_id,
            "summary": summary_text,
            "customer_sentiment": sentiment,
            "Information_bucket": Information_bucket,
            "escalation_required": escalation_required,
            "task_type": task_type,
            "db_change_required": db_change_required,
            "routing_source": routing_source
        }

    except Exception as e:
        logger.error(f"Analyzer error: {e}\n{traceback.format_exc()}")
        return {
            "error": "LLM processing failed",
            "details": str(e)
        }

# ---------------------------
# Run (for local dev)
# ---------------------------
if __name__ == '__main__':
    port = int(os.getenv("PORT", 5000))
    logger.info(f"Starting Flask app on port {port}")
    app.run(debug=(LOG_LEVEL == "DEBUG"), host="0.0.0.0", port=port)
