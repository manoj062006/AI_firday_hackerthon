# test_backend.py
import requests
import time

BASE_URL = "http://localhost:5000/api/chat"
SESSION_ID = "recap_test_session"


def stream_chat(message, description=""):
    print(f"\n--- {description} ---")
    print(f"User: {message}")

    start = time.time()
    try:
        response = requests.post(
            BASE_URL,
            json={"message": message, "sessionId": SESSION_ID},
            stream=True
        )

        full_response = ""
        print("AI:", end=" ")

        for chunk in response.iter_content(chunk_size=64):
            if chunk:
                text = chunk.decode("utf-8")
                full_response += text
                print(text, end="", flush=True)

        latency = time.time() - start
        print(f"\nLatency: {latency:.2f}s")

        # Recap detection
        if "Conversation recap to preserve context" in full_response:
            print("🔄 RECAP TRIGGERED")

        return full_response

    except Exception as e:
        print(f"[ERROR] {e}")
        return None


# --------------------------------------
# 1. Test Empathy Response
# --------------------------------------
stream_chat(
    "I am really frustrated! My refund hasn't arrived yet.",
    "Test 1 — Empathy Check"
)

# --------------------------------------
# 2. Test Knowledge Base Response
# --------------------------------------
stream_chat(
    "I purchased the subscription from the App Store. Can I get a refund?",
    "Test 2 — Knowledge Base"
)

# --------------------------------------
# 3. Test Context Recall
# --------------------------------------
stream_chat(
    "Wait, how many days did you say a refund normally takes?",
    "Test 3 — Context Recall"
)

# --------------------------------------
# 4. Test AUTO-RECAP Trigger (Very Long Context)
# --------------------------------------
large_text = "Please explain my broadband plan details again. " * 120  # ~10,000 characters
stream_chat(
    large_text,
    "Test 4 — Trigger Auto-Recap Due to Token Limit"
)

# --------------------------------------
# 5. Test Response After Recap (Should Use Summary)
# --------------------------------------
stream_chat(
    "Okay, based on what we discussed earlier, what should I do next?",
    "Test 5 — Verify Post-Recap Continuity"
)
