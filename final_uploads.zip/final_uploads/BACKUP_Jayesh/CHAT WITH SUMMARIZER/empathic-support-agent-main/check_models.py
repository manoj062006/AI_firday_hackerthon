# check_models.py
from langchain_openai import ChatOpenAI
import httpx
import os

client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url=os.getenv("LLM_BASE_URL", "https://genailab.tcs.in"),
    model=os.getenv("LLM_MODEL", "gemini-2.5-flash"),
    api_key=os.getenv("LLM_API_KEY", "sk-QIOxO8UXL369Fc6SBzAPPw"),
    http_client=client,
)

try:
    print("Testing LLM availability...")
    response = llm.invoke("Say 'Hello, the API is working.'")
    print("\nLLM Response:")
    print(response.content)
    print("\n✅ SUCCESS: API-key LLM is working.")
except Exception as e:
    print("\n❌ ERROR: LLM test failed")
    print(str(e))
