import os
import requests
import urllib3
import httpx
import ssl
import json 
from dotenv import load_dotenv
# --- SECURITY WARNING ---
# WARNING: Disabling SSL verification is DANGEROUS and should only be used 
# for temporary debugging in highly controlled environments where you understand 
# the risks (e.g., corporate proxies causing certificate issues).
# DO NOT use this in production.
# The proper solution is to install your corporate CA certificate.
# --------------------------

# --- CONFIGURATION ---
load_dotenv()

GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")
MODEL_NAME = "gemini-2.5-flash"
API_ENDPOINT = "https://generativelanguage.googleapis.com"
API_URL = f"{API_ENDPOINT}/v1beta/models/{MODEL_NAME}:generateContent"
# ---------------------


# 1. Disable Insecure Request Warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
#print("InsecureRequestWarning from urllib3 disabled.")
#print("-" * 50)


# --- PART 1: Demonstrating with the 'requests' library (Confirmed Working) ---
""" 
try:
    print("Attempting requests.get('https://google.com', verify=False)...")
    response = requests.get("https://google.com", verify=False)
    print(f"Successfully connected to Google with SSL disabled.")
    print(f"Status Code: {response.status_code}")
except Exception as e:
    print(f"requests library failed despite verify=False. Error: {e}")

print("-" * 50)

"""
# --- PART 2: Reusable Function for LLM Connection ---

def llm(model: str, prompt: str) -> str:
    """
    Sends a direct request to the Gemini API using an httpx.Client 
    with SSL verification disabled.

    Args:
        client: The configured httpx.Client with SSL bypass.
        api_key: Your Google AI API key.
        model: The model identifier (e.g., 'gemini-2.5-flash').
        prompt: The text prompt to send to the model.

    Returns:
        The generated text content, or an error message.
    """
    # 3b. Create the custom httpx.Client
#print("Creating custom httpx.Client using the unverified SSL context...")
    client = httpx.Client(
        verify=unverified_ssl_context, 
        timeout=None,
        trust_env=False 
    )
    api_key= GOOGLE_API_KEY
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    
    payload = {
        "contents": [{"parts": [{"text": prompt}]}]
    }
    
    headers = {
        "x-goog-api-key": api_key,
        "Content-Type": "application/json"
    }

    try:
        response = client.post(url, headers=headers, json=payload)
        
        # Check for successful connection but potential API error status codes
        if response.status_code == 200:
            response_data = response.json()
            # Basic check to extract the text
            if 'candidates' in response_data and response_data['candidates']:
                client.close()
                return response_data['candidates'][0]['content']['parts'][0]['text']
                
            else:
                client.close()
                return f"Error: API returned success (200) but missing content in response: {response.text}"
                 
        elif response.status_code == 400:
            return f"API Error (400 Bad Request): Invalid API Key or malformed payload. Response: {response.text}"
        elif response.status_code == 403:
            return f"API Error (403 Forbidden): API key may not be enabled for the Gemini API. Response: {response.text}"
        else:
            client.close()
            return f"API Error ({response.status_code}): Unexpected status code. Response: {response.text}"

    except ssl.SSLError as e:
        return f"CRITICAL SSLError: Failed despite unverified client. Error: {e}"
    except Exception as e:
        return f"General Error during API call: {e}"
    

# --- PART 3: Main Execution and Demonstration ---

# 3a. Create the unverified SSL Context
#print("Creating unverified SSL context...")
unverified_ssl_context = ssl.create_default_context()
unverified_ssl_context.check_hostname = False
unverified_ssl_context.verify_mode = ssl.CERT_NONE

custom_client = httpx.Client(
        verify=unverified_ssl_context, 
        timeout=None,
        trust_env=False 
    )
"""  
# 3c. Test the client on the base URL (for completeness)
try:
    print(f"Testing custom httpx client directly on base URL: {API_ENDPOINT}...")
    test_response = custom_client.get(API_ENDPOINT)
    print(f"httpx client GET test successful. Status Code: {test_response.status_code} (404 is expected for the base URL)")
except Exception as e:
    print(f"CRITICAL: Direct httpx GET test failed. Error: {e}")

print("-" * 50)
""" 
# 3d. DEMONSTRATION: Call the new reusable function
print("DEMONSTRATION: Calling the reusable 'generate_content_unverified' function...")

prompt_to_llm = "Hello this is a test call. Responsed sucessful"

llm_response_text = llm(
    model=MODEL_NAME, 
    prompt=prompt_to_llm
)

print(f"\n--- LLM Invocation Status ---")
print(f"Prompt: {prompt_to_llm}")
print(f"Result:\n{llm_response_text}")

# 3e. IMPORTANT: Close the custom httpx client
custom_client.close()
print("-" * 50)
print("Custom httpx.Client closed.")