from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Literal, Optional
import regex as re
from langchain_openai import ChatOpenAI
import httpx
import json
# from utils.Custom_llm import llm



client = httpx.Client(verify=False)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in", 
    model="gemini-2.5-flash",
    api_key="sk-QIOxO8UXL369Fc6SBzAPPw",  
    http_client=client
)

app = FastAPI()
MODEL_NAME = "gemini-2.5-flash"

# ---------- DATA MODELS ----------

class Message(BaseModel):
    sender: Literal["user", "bot"]
    text: str

class ConversationRequest(BaseModel):
    conversation_id: Optional[str] = None
    messages: List[Message]


@app.get("/")
def home():
    return {"message": "Customer Review Analyzer API is running ✅"}

def extract_json(text: str):
    """
    Extract the first JSON object found in a string.
    Returns a dict or None.
    """
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return None
    try:
        return json.loads(match.group(0))
    except:
        return None


@app.post("/analyze")
def analyze_conversation(payload: ConversationRequest):

    sentiment = {
        "label": "NEUTRAL",
        "score": 0
    }
    Information_bucket = []

    try:
        # ✅ Combine only USER messages
        customer_text = " ".join(
            [m.text for m in payload.messages if m.sender == "user"]
        ).strip()

        # ✅ Combine FULL conversation
        full_conversation = "\n".join(
            [f"{m.sender.upper()}: {m.text}" for m in payload.messages]
        ).strip()

        # -------- SENTIMENT (-100 to +100) --------

        if customer_text:
            sentiment_prompt = f"""
You are a sentiment scoring engine.

Return ONLY valid JSON:
{{"score": -100 to +100}}

Rules:
- -100 = extremely negative
- 0 = neutral
- +100 = extremely positive

Customer text:
\"\"\"{customer_text}\"\"\"
"""

            sentiment_response = llm.invoke(sentiment_prompt)
            sentiment_raw = sentiment_response.content.strip()

            parsed = extract_json(sentiment_raw)

            if parsed and "score" in parsed:
                score = int(parsed["score"])

                if score < -20:
                    label = "NEGATIVE"
                elif score > 20:
                    label = "POSITIVE"
                else:
                    label = "NEUTRAL"

                sentiment = {
                    "label": label,
                    "score": score
                }

        # -------- SUMMARY --------

        summary_prompt = f"""
Summarize the following customer support conversation in 2–3 clear sentences:

Conversation:
{full_conversation}
"""

        summary_response = llm.invoke(summary_prompt)
        summary_text = summary_response.content.strip()

        # -------- KEY POINTS --------

#         keypoints_prompt = f"""
# Extract 2 to 3 clear, actionable key points  from the following conversation.

# Return ONLY valid JSON:
# {{
#   "Information_bucket": [
#     "point 1",
#     "point 2",
#     "point 3"
#   ]
# }}

# Conversation:
# {full_conversation}
# """


        keypoints_prompt = f"""
Extract ONLY the final OUTCOME, SOLUTION, or CONCLUSION from the following customer support conversation.

STRICT RULES:
- Do NOT include complaints or emotions
- Do NOT include intermediate troubleshooting
- ONLY include final decisions, promises, actions, or resolutions
- Return 2 to 3 bullet points MAX

Return ONLY valid JSON in this exact format:
{{
  "Information_bucket": [
    "final outcome 1",
    "final outcome 2"
  ]
}}

Conversation:
{full_conversation}
"""




        keypoints_response = llm.invoke(keypoints_prompt)
        keypoints_raw = keypoints_response.content.strip()

        keypoints_parsed = extract_json(keypoints_raw)

        if keypoints_parsed and "Information_bucket" in keypoints_parsed:
            Information_bucket = keypoints_parsed["Information_bucket"]



        # -------- RULE-BASED ROUTING (FAST PATH) --------

        task_type = "SIMPLE"
        db_change_required = False
        routing_source = "RULES"

        routing_keywords = [
            "refund", "technician", "appointment", "visit",
            "complaint", "dispute", "deducted", "failed",
            "reversed", "compensation", "switch", "legal",
            "cancel", "update", "address", "subscription"
        ]

        combined_rule_text = " ".join(Information_bucket).lower() + " " + full_conversation.lower()

        for word in routing_keywords:
            if word in combined_rule_text:
                task_type = "COMPLEX"
                db_change_required = True
                break


        # -------- LLM ROUTING VALIDATION (SMART LAYER) --------

        routing_prompt = f"""
You are a customer support workflow classifier.

Decide:
1. Is this a SIMPLE task or a COMPLEX task?
2. Does this require a backend DATABASE change?

Definitions:
- SIMPLE: informational, FAQ, status check, no backend update needed
- COMPLEX: refund, appointment, technician, complaint, cancellation, update, dispute

Return ONLY valid JSON in this format:
{{
  "task_type": "SIMPLE | COMPLEX",
  "db_change_required": true | false
}}

Conversation:
{full_conversation}
"""

        routing_response = llm.invoke(routing_prompt)
        routing_raw = routing_response.content.strip()

        routing_parsed = extract_json(routing_raw)

        # ✅ HYBRID DECISION LOGIC
        if routing_parsed and "task_type" in routing_parsed and "db_change_required" in routing_parsed:
            llm_task = routing_parsed["task_type"]
            llm_db_flag = bool(routing_parsed["db_change_required"])

            # If LLM disagrees with rules → mark as HYBRID and accept LLM
            if llm_task != task_type or llm_db_flag != db_change_required:
                task_type = llm_task
                db_change_required = llm_db_flag
                routing_source = "HYBRID"






        # -------- AUTO ESCALATION LOGIC --------

        escalation_required = False

        # Rule 1: Very negative sentiment
        if sentiment["score"] <= -60:
            escalation_required = True

        # Rule 2: Critical keywords in key points
        critical_keywords = ["technician", "refund", "complaint", "switch", "legal", "escalate"]

        for point in Information_bucket:
            for word in critical_keywords:
                if word.lower() in point.lower():
                    escalation_required = True
                    break



        # # -------- TASK ROUTING LOGIC --------

        # task_type = "SIMPLE"
        # db_change_required = False

        # routing_keywords = [
        #     "refund", "technician", "appointment", "visit",
        #     "complaint", "dispute", "deducted", "failed",
        #     "reversed", "compensation", "switch", "legal"
        # ]

        # combined_text = " ".join(Information_bucket) + " " + full_conversation.lower()

        # for word in routing_keywords:
        #     if word in combined_text.lower():
        #         task_type = "COMPLEX"
        #         db_change_required = True
        #         break




        # ✅ FINAL SAFE RETURN
        return {
            "conversation_id": payload.conversation_id,
            "summary": summary_text,
            "customer_sentiment": sentiment,
            "Information_bucket": Information_bucket,
            "escalation_required": escalation_required,
            "task_type": task_type,
            "db_change_required": db_change_required,
            "routing_source": routing_source
        }




    except Exception as e:
        return {
            "error": "LLM processing failed",
            "details": str(e)
        }








# @app.post("/analyze")
# def analyze_conversation(payload: ConversationRequest):

#     # ✅ PRE-INITIALIZE SAFETY DEFAULTS
#     sentiment = {
#         "label": "NEUTRAL",
#         "score": 0
#     }
#     Information_bucket = []
#     task_type = "SIMPLE"
#     db_change_required = False
#     routing_source = "RULES"
#     escalation_required = False

#     try:
#         # ✅ Combine only USER messages
#         customer_text = " ".join(
#             [m.text for m in payload.messages if m.sender == "user"]
#         ).strip()

#         # ✅ Combine FULL conversation
#         full_conversation = "\n".join(
#             [f"{m.sender.upper()}: {m.text}" for m in payload.messages]
#         ).strip()

#         # -------- SENTIMENT (-100 to +100) --------

#         if customer_text:
#             sentiment_prompt = f"""
# You are a sentiment scoring engine.

# Return ONLY valid JSON:
# {{"score": -100 to +100}}

# Rules:
# - -100 = extremely negative
# - 0 = neutral
# - +100 = extremely positive

# Customer text:
# \"\"\"{customer_text}\"\"\"
# """

#             sentiment_raw = llm(MODEL_NAME, sentiment_prompt).strip()
#             parsed = extract_json(sentiment_raw)

#             if parsed and "score" in parsed:
#                 score = int(parsed["score"])

#                 if score < -20:
#                     label = "NEGATIVE"
#                 elif score > 20:
#                     label = "POSITIVE"
#                 else:
#                     label = "NEUTRAL"

#                 sentiment = {
#                     "label": label,
#                     "score": score
#                 }

#         # -------- SUMMARY --------

#         summary_prompt = f"""
# Summarize the following customer support conversation in 2–3 clear sentences:

# Conversation:
# {full_conversation}
# """

#         summary_text = llm(MODEL_NAME, summary_prompt).strip()

#         # -------- KEY POINTS (OUTCOME ONLY) --------

#         keypoints_prompt = f"""
# Extract ONLY the final OUTCOME, SOLUTION, or CONCLUSION from the following customer support conversation.

# STRICT RULES:
# - Do NOT include complaints or emotions
# - Do NOT include intermediate troubleshooting
# - ONLY include final decisions, promises, actions, or resolutions
# - Return 2 to 3 bullet points MAX

# Return ONLY valid JSON in this exact format:
# {{
#   "Information_bucket": [
#     "final outcome 1",
#     "final outcome 2"
#   ]
# }}

# Conversation:
# {full_conversation}
# """

#         keypoints_raw = llm(MODEL_NAME, keypoints_prompt).strip()
#         keypoints_parsed = extract_json(keypoints_raw)

#         if keypoints_parsed and "Information_bucket" in keypoints_parsed:
#             Information_bucket = keypoints_parsed["Information_bucket"]

  


#         # -------- AUTO ESCALATION LOGIC --------

#         if sentiment["score"] <= -60:
#             escalation_required = True

#         critical_keywords = ["technician", "refund", "complaint", "switch", "legal", "escalate"]

#         for point in Information_bucket:
#             for word in critical_keywords:
#                 if word.lower() in point.lower():
#                     escalation_required = True
#                     break

#         # ✅ FINAL SAFE RETURN
#         return {
#             "conversation_id": payload.conversation_id,
#             "summary": summary_text,
#             "customer_sentiment": sentiment,
#             "Information_bucket": Information_bucket,
#             # "escalation_required": escalation_required,
#             # "task_type": task_type,
#             # "db_change_required": db_change_required,
#             # "routing_source": routing_source
#         }

#     except Exception as e:
#         return {
#             "error": "LLM processing failed",
#             "details": str(e)
#         }

