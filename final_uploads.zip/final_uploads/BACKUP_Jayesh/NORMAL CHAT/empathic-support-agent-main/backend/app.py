# backend/app.py
import os
import json
from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()
from backend.db import init_db, seed_plans, get_session, create_session, get_user_by_user_id
from backend.db import get_user_by_username
from backend.db import get_plan_by_plan_id
from backend import models
from backend.scrubber import scrub_output
from backend.knowledge_base import search_knowledge_base

# initialize db & seed plans (idempotent)
init_db()
try:
    # attempt seeding from backend.telecom_db if present
    from backend.telecom_db import PLANS_DB
    seed_plans([PLANS_DB[k] for k in PLANS_DB])
except Exception:
    try:
        # fallback to top-level telecom_db
        from telecom_db import PLANS_DB
        seed_plans([PLANS_DB[k] for k in PLANS_DB])
    except Exception:
        pass

app = Flask(__name__)
CORS(app)

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json or {}
    username = data.get('username')
    password = data.get('password')
    name = data.get('name')
    email = data.get('email')
    phone = data.get('phone')
    plan_id = data.get('plan_id')

    if not username or not password or not name:
        return jsonify({"error":"username, password and name are required"}), 400

    if get_user_by_username(username):
        return jsonify({"error":"username already exists"}), 400

    from backend.auth import hash_password, generate_user_id
    user_id = generate_user_id()
    pwd_hash = hash_password(password)
    try:
        from backend.db import create_user
        create_user(user_id, username, pwd_hash, name, email, phone, plan_id)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    # create session
    session_id = "sess_" + os.urandom(8).hex()
    create_session(session_id, user_id)

    return jsonify({"success":True, "user_id": user_id, "name": name, "sessionId": session_id})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json or {}
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({"error":"username and password required"}), 400

    user = get_user_by_username(username)
    if not user:
        return jsonify({"error":"Invalid credentials"}), 401

    from backend.auth import check_password
    if not check_password(password, user.get('password_hash','')):
        return jsonify({"error":"Invalid credentials"}), 401

    session_id = "sess_" + os.urandom(8).hex()
    create_session(session_id, user['user_id'])
    return jsonify({"success": True, "user_id": user['user_id'], "name": user['name'], "sessionId": session_id})

@app.route('/api/me', methods=['GET'])
def me():
    session_id = request.headers.get('X-Session-Id') or request.args.get('sessionId')
    if not session_id:
        return jsonify({"error":"no session"}), 401
    sess = get_session(session_id)
    if not sess:
        return jsonify({"error":"invalid session"}), 401
    user = get_user_by_user_id(sess['user_id'])
    if not user:
        return jsonify({"error":"user not found"}), 404
    return jsonify({"user": user})

@app.route('/api/reset', methods=['POST'])
def reset():
    data = request.json or {}
    session_id = data.get('sessionId')
    if session_id:
        # simple removal from sessions table by overriding with empty user
        from backend.db import get_conn
        conn = get_conn()
        with conn:
            conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
    return jsonify({"status":"cleared"})

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json or {}
    session_id = data.get("sessionId")
    user_message = (data.get("message") or "").strip()

    if not session_id or not user_message:
        return jsonify({"error":"Missing message or sessionId"}), 400

    # 1. resolve session -> user
    sess = get_session(session_id)
    if not sess:
        return jsonify({"error":"Invalid session"}), 401
    auth_user = get_user_by_user_id(sess['user_id'])
    if not auth_user:
        return jsonify({"error":"User not found"}), 404

    # 2. sentiment
    from backend.sentiment import detect as detect_sentiment
    sentiment = detect_sentiment(user_message)

    # 3. knowledge base
    kb_context = search_knowledge_base(user_message)

    # 4. build user_info for prompt_builder
    plan = None
    if auth_user.get('plan_id'):
        plan = get_plan_by_plan_id(auth_user['plan_id'])
    user_info = {
        "user_id": auth_user.get('user_id'),
        "name": auth_user.get('name'),
        "account_status": auth_user.get('account_status'),
        "plan_id": auth_user.get('plan_id'),
        "plan_name": plan.get('name') if plan else None,
        "data_usage_gb": auth_user.get('data_usage_gb'),
        "data_limit_gb": auth_user.get('data_limit_gb'),
        "bill_amount": auth_user.get('bill_amount'),
        "due_date": auth_user.get('due_date'),
        "email": auth_user.get('email'),
        "phone": auth_user.get('phone')
    }

    # 5. build prompt
    from backend.prompt_builder import build_prompt
    prompt_text = build_prompt(user_message=user_message, user_info=user_info, sentiment=sentiment, kb_context=kb_context)

    # 6. generator
    def generate():
        try:
            meta = json.dumps({"sentiment": sentiment.get('label'), "score": sentiment.get('score')})
            yield f"__META__:{meta}\n"

            resp = models.run_premium(prompt_text, stream=False)
            resp = scrub_output(resp, user_info)
            yield resp


        except Exception as e:
            # friendly telecom-style fallback
            yield (
                "I'm really sorry — I'm having a bit of trouble reaching the system right now. "
                "Please try again in a moment, and I'll be right here to help you."
            )

    return Response(stream_with_context(generate()), mimetype='text/plain')

if __name__ == "__main__":
    app.run(debug=True, port=int(os.getenv("PORT", 5000)))
