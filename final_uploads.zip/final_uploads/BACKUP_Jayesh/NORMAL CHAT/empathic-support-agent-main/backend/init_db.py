# backend/init_db.py
from backend.db import init_db, seed_plans, get_conn
from backend.auth import hash_password
import backend.db as dbmod
import json
import os

# If you have the old telecom_db.py inside backend, import from there:
try:
    from backend.telecom_db import PLANS_DB, USERS_DB
except Exception:
    # fallback: try top-level telecom_db (older structure)
    from telecom_db import PLANS_DB, USERS_DB

def seed_all():
    init_db()
    plans = [PLANS_DB[k] for k in PLANS_DB]
    seed_plans(plans)

    conn = get_conn()
    with conn:
        for uid, u in USERS_DB.items():
            try:
                conn.execute("""INSERT OR IGNORE INTO users (user_id, username, password_hash, name, email, phone, plan_id, account_status, data_usage_gb, data_limit_gb, bill_amount, due_date, suspension_reason)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                             (u['id'], u['username'], hash_password(u.get('password','changeme')), u['name'], u['email'], u['phone'], u['plan_id'], u['account_status'], u['data_usage_gb'], str(u['data_limit_gb']), u['bill_amount'], u['due_date'], u.get('suspension_reason')))
            except Exception as e:
                print("Seed user error:", e)
    print("DB initialized and seeded.")

if __name__ == "__main__":
    seed_all()
