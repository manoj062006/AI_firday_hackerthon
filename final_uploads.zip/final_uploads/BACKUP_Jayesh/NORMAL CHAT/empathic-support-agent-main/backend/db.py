# backend/db.py
import os
import sqlite3
from sqlite3 import Connection
from contextlib import closing
from dotenv import load_dotenv
import json

load_dotenv()
DB_URL = os.getenv("DATABASE_URL", "sqlite:///./telecom.db")
DB_PATH = DB_URL.replace("sqlite:///", "") if DB_URL.startswith("sqlite:///") else DB_URL

def get_conn() -> Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    sql = """
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT UNIQUE,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        plan_id TEXT,
        account_status TEXT DEFAULT 'active',
        data_usage_gb INTEGER DEFAULT 0,
        data_limit_gb TEXT DEFAULT '0',
        bill_amount REAL DEFAULT 0,
        due_date TEXT,
        suspension_reason TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_id TEXT UNIQUE NOT NULL,
        name TEXT,
        type TEXT,
        speed TEXT,
        data_limit_gb TEXT,
        price REAL,
        validity_days INTEGER,
        features TEXT
    );

    CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT UNIQUE,
        user_id TEXT,
        data TEXT,
        last_active TEXT DEFAULT CURRENT_TIMESTAMP
    );
    """
    conn = get_conn()
    with closing(conn):
        conn.executescript(sql)
        conn.commit()

def seed_plans(plans):
    conn = get_conn()
    with conn:
        for p in plans:
            conn.execute(
                """INSERT OR IGNORE INTO plans (plan_id, name, type, speed, data_limit_gb, price, validity_days, features)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (p['id'], p['name'], p.get('type',''), p.get('speed',''), str(p.get('data_limit_gb','')), p.get('price',0), p.get('validity_days',30), json.dumps(p.get('features',[])))
            )

def get_user_by_user_id(user_id):
    conn = get_conn()
    cur = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    row = cur.fetchone()
    return dict(row) if row else None

def get_user_by_username(username):
    conn = get_conn()
    cur = conn.execute("SELECT * FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    return dict(row) if row else None

def create_user(user_id, username, password_hash, name, email, phone, plan_id=None):
    conn = get_conn()
    with conn:
        conn.execute("""INSERT INTO users (user_id, username, password_hash, name, email, phone, plan_id)
                        VALUES (?, ?, ?, ?, ?, ?, ?)""",
                     (user_id, username, password_hash, name, email, phone, plan_id))

def get_plan_by_plan_id(plan_id):
    conn = get_conn()
    cur = conn.execute("SELECT * FROM plans WHERE plan_id = ?", (plan_id,))
    row = cur.fetchone()
    if not row:
        return None
    r = dict(row)
    try:
        r['features'] = json.loads(r.get('features') or '[]')
    except Exception:
        r['features'] = []
    return r

def create_session(session_id, user_id):
    conn = get_conn()
    with conn:
        conn.execute("INSERT OR REPLACE INTO sessions (session_id, user_id) VALUES (?, ?)", (session_id, user_id))

def get_session(session_id):
    conn = get_conn()
    cur = conn.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,))
    row = cur.fetchone()
    return dict(row) if row else None
