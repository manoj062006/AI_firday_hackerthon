# backend/models.py
import os
import httpx
from dotenv import load_dotenv
load_dotenv()

# Force provider = premium ONLY
MODEL_PROVIDER = "premium"

OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gemini-2.5-pro")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "sk-QIOxO8UXL369Fc6SBzAPPw")


def run_premium(prompt_text: str, stream=False):
    """
    Premium provider ONLY.
    Uses the official OpenAI API (or API-compatible endpoints) via HTTPX.
    Always returns a final string (no streaming).
    """
    if not OPENAI_API_KEY:
        return "[MODEL ERROR] Missing OPENAI_API_KEY in .env"

    try:
        url = f"{OPENAI_BASE_URL}/chat/completions"

        headers = {
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": OPENAI_MODEL,
            "messages": [
                {"role": "system", "content": ""},
                {"role": "user", "content": prompt_text}
            ],
            "max_tokens": 800
        }

        with httpx.Client(verify=False, timeout=30.0) as client:
            r = client.post(url, json=payload, headers=headers)
            r.raise_for_status()
            data = r.json()

        # Extract model response text
        try:
            return data["choices"][0]["message"]["content"]
        except Exception:
            return str(data)

    except Exception as e:
        return f"[MODEL ERROR] Premium call failed: {e}"
