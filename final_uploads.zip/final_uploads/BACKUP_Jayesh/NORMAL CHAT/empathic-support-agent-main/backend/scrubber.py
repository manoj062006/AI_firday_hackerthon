# backend/scrubber.py
import re

def scrub_output(text: str, user_info: dict) -> str:
    if not isinstance(text, str):
        return ""

    # Protect other user IDs
    allowed_id = user_info.get("user_id") or user_info.get("id") or ""
    text = re.sub(r"\bU\d{3}\b", lambda m: m.group(0) if m.group(0) == allowed_id else "[REDACTED_USER]", text)

    # Protect phone numbers
    allowed_phone = (user_info.get("phone") or "").replace(" ", "")
    def mask_phone(m):
        phone = m.group(0)
        if allowed_phone and allowed_phone in phone.replace(" ", ""):
            return phone
        return "[REDACTED_PHONE]"
    text = re.sub(r"\+?\d[\d\s\-\(\)]{7,}\d", mask_phone, text)

    # Protect emails
    allowed_email = (user_info.get("email") or "").lower()
    def mask_email(m):
        email = m.group(0)
        if allowed_email and email.lower() == allowed_email:
            return email
        return "[REDACTED_EMAIL]"
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", mask_email, text)

    # Remove obvious model debug strings
    text = re.sub(r"model='.*?'", "[REDACTED_MODEL]", text)
    text = re.sub(r"created_at=.*?Z", "", text)
    text = re.sub(r"done=False|done=True", "", text)

    # tidy
    text = re.sub(r"\s{2,}", " ", text).strip()
    return text
