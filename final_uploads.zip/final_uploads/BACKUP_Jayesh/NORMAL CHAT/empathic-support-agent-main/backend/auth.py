# backend/auth.py (final)
import bcrypt
from backend.db import get_session, get_user_by_user_id, get_conn

def hash_password(plain: str) -> str:
    return bcrypt.hashpw(plain.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def check_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode('utf-8'), hashed.encode('utf-8'))
    except Exception:
        return False

def generate_user_id():
    conn = get_conn()
    cur = conn.execute("SELECT COUNT(*) as c FROM users")
    row = cur.fetchone()
    c = row[0] if row else 0
    return f"U{c+1:03d}"

def get_user_from_session(session_id: str):
    """
    Return user dict for given session_id or None.
    """
    sess = get_session(session_id)
    if not sess:
        return None
    user_id = sess.get("user_id") or sess.get("user_id")
    if not user_id:
        return None
    return get_user_by_user_id(user_id)
