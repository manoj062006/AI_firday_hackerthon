"""
Mock Database for Telecom Service Provider
Contains users and their plan information
"""

# Mock Users Database
USERS_DB = {
    "U001": {
        "id": "U001",
        "username": "rajesh.kumar",
        "password": "pass1234",
        "name": "Rajesh Kumar",
        "email": "rajesh.kumar@email.com",
        "phone": "+91-9876543210",
        "plan_id": "PLAN_FIBER_500",
        "account_status": "active",
        "billing_cycle": "monthly",
        "data_usage_gb": 245,
        "data_limit_gb": 500,
        "bill_amount": 999,
        "due_date": "2025-12-10"
    },
    "U002": {
        "id": "U002",
        "username": "priya.sharma",
        "password": "pass5678",
        "name": "Priya Sharma",
        "email": "priya.sharma@email.com",
        "phone": "+91-9123456789",
        "plan_id": "PLAN_FIBER_200",
        "account_status": "active",
        "billing_cycle": "monthly",
        "data_usage_gb": 180,
        "data_limit_gb": 200,
        "bill_amount": 699,
        "due_date": "2025-12-05"
    },
    "U003": {
        "id": "U003",
        "username": "amit.patel",
        "password": "pass9012",
        "name": "Amit Patel",
        "email": "amit.patel@email.com",
        "phone": "+91-9988776655",
        "plan_id": "PLAN_MOBILE_UNLIMITED",
        "account_status": "active",
        "billing_cycle": "monthly",
        "data_usage_gb": 85,
        "data_limit_gb": "unlimited",
        "bill_amount": 599,
        "due_date": "2025-12-15"
    },
    "U004": {
        "id": "U004",
        "username": "vignesh.raaghav",
        "password": "pass3456",
        "name": "Vighnesh Raaghav",
        "email": "vighnesh.raaghav@email.com",
        "phone": "+91-9445566778",
        "plan_id": "PLAN_FIBER_1000",
        "account_status": "suspended",
        "billing_cycle": "monthly",
        "data_usage_gb": 890,
        "data_limit_gb": 1000,
        "bill_amount": 1499,
        "due_date": "2025-11-28",
        "suspension_reason": "Payment overdue"
    },
    "U005": {
        "id": "U005",
        "username": "manoj.kumar",
        "password": "pass7890",
        "name": "Manoj Kumar",
        "email": "manoj.kumar@email.com",
        "phone": "+91-9334455667",
        "plan_id": "PLAN_MOBILE_50GB",
        "account_status": "active",
        "billing_cycle": "monthly",
        "data_usage_gb": 42,
        "data_limit_gb": 50,
        "bill_amount": 399,
        "due_date": "2025-12-12"
    }
}

# Telecom Plans Database
PLANS_DB = {
    "PLAN_FIBER_200": {
        "id": "PLAN_FIBER_200",
        "name": "Fiber Basic 200",
        "type": "broadband",
        "speed": "200 Mbps",
        "data_limit_gb": 200,
        "price": 699,
        "validity_days": 30,
        "features": ["Free router", "24/7 support", "No installation charges"]
    },
    "PLAN_FIBER_500": {
        "id": "PLAN_FIBER_500",
        "name": "Fiber Plus 500",
        "type": "broadband",
        "speed": "500 Mbps",
        "data_limit_gb": 500,
        "price": 999,
        "validity_days": 30,
        "features": ["Free router", "24/7 support", "Free OTT subscription", "No installation charges"]
    },
    "PLAN_FIBER_1000": {
        "id": "PLAN_FIBER_1000",
        "name": "Fiber Ultra 1000",
        "type": "broadband",
        "speed": "1 Gbps",
        "data_limit_gb": 1000,
        "price": 1499,
        "validity_days": 30,
        "features": ["Free router", "Priority support", "Free OTT subscriptions (3)", "Static IP", "No installation charges"]
    },
    "PLAN_MOBILE_50GB": {
        "id": "PLAN_MOBILE_50GB",
        "name": "Mobile Value 50GB",
        "type": "mobile",
        "speed": "4G/5G",
        "data_limit_gb": 50,
        "price": 399,
        "validity_days": 30,
        "features": ["Unlimited calls", "100 SMS/day", "4G/5G data"]
    },
    "PLAN_MOBILE_UNLIMITED": {
        "id": "PLAN_MOBILE_UNLIMITED",
        "name": "Mobile Unlimited",
        "type": "mobile",
        "speed": "4G/5G",
        "data_limit_gb": "unlimited",
        "price": 599,
        "validity_days": 30,
        "features": ["Unlimited calls", "Unlimited SMS", "Truly unlimited 5G data", "Free Amazon Prime"]
    }
}

def get_user_by_id(user_id):
    """Get user information by user ID"""
    return USERS_DB.get(user_id.upper())

def get_plan_by_id(plan_id):
    """Get plan information by plan ID"""
    return PLANS_DB.get(plan_id.upper())

def get_user_plan_info(user_id):
    """Get complete user and plan information"""
    user = get_user_by_id(user_id)
    if not user:
        return None
    
    plan = get_plan_by_id(user["plan_id"])
    return {
        "user": user,
        "plan": plan
    }

def search_user_by_phone(phone):
    """Search user by phone number"""
    for user_id, user in USERS_DB.items():
        if user["phone"] == phone:
            return user
    return None

def authenticate_user(username, password):
    """Authenticate user by username and password"""
    for user_id, user in USERS_DB.items():
        if user.get("username") == username and user.get("password") == password:
            return user
    return None
