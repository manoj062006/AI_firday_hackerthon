import sqlite3
from backend.db import get_conn

conn = get_conn()
cur = conn.cursor()

cur.execute("SELECT id, username, name, email, phone, plan_id FROM users")
rows = cur.fetchall()

print("\n=== Existing Users ===\n")
for r in rows:
    print(f"UserID: {r[0]}")
    print(f"Username: {r[1]}")
    print(f"Name: {r[2]}")
    print(f"Email: {r[3]}")
    print(f"Phone: {r[4]}")
    print(f"Plan: {r[5]}")
    print("-" * 30)
