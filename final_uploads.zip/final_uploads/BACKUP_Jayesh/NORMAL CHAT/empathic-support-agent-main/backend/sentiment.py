# backend/sentiment.py
import re

NEGATIVE_WORDS = {
    "frustrated", "angry", "upset", "annoyed", "irritated", "mad",
    "disappointed", "sad", "tired", "exhausted", "depressed",
    "lonely", "worried", "stressed", "terrible", "bad", "horrible"
}

POSITIVE_WORDS = {
    "happy", "great", "awesome", "amazing", "perfect",
    "good", "wonderful", "glad", "excited", "love", "nice"
}

INTENSIFIERS = {"very", "really", "so", "extremely", "super", "totally"}

def detect(text: str) -> dict:
    """
    Lightweight sentiment detection.
    Returns dict: {'label': ..., 'score': float}
    """
    if not text or not isinstance(text, str):
        return {"label": "neutral", "score": 0.0}

    text_lower = text.lower()
    words = re.findall(r"\b\w+\b", text_lower)

    neg_hits = [w for w in words if w in NEGATIVE_WORDS]
    pos_hits = [w for w in words if w in POSITIVE_WORDS]
    intensifiers = [w for w in words if w in INTENSIFIERS]

    intensity = 1 + (0.3 * len(intensifiers))
    neg_score = len(neg_hits) * intensity
    pos_score = len(pos_hits) * intensity

    if neg_score > 0 and neg_score >= pos_score:
        if any(w in neg_hits for w in ["frustrated", "angry", "annoyed", "irritated", "mad"]):
            return {"label": "angry", "score": min(1.0, 0.5 + neg_score / 10)}
        return {"label": "sad", "score": min(1.0, 0.4 + neg_score / 10)}

    if pos_score > 0:
        return {"label": "positive", "score": min(1.0, 0.4 + pos_score / 10)}

    return {"label": "neutral", "score": 0.0}
