1. Ensure Python packages installed: flask, flask-cors, python-dotenv, bcrypt, httpx, ollama, vaderSentiment, langchain_openai (if using premium).
2. Copy .env.example -> .env and fill values.
3. Initialize DB & seed:
   python backend/init_db.py
4. Run backend:
   python -m backend.app
5. Open frontend:
   open frontend/login.html in browser (or serve via simple http server)
