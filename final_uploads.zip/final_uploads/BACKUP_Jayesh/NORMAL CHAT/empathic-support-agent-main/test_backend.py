# test_backend.py
import requests
import time

BASE_LOGIN = "http://localhost:5000/api/login"
BASE_CHAT = "http://localhost:5000/api/chat"

# 1. login as seeded user (e.g., rajesh.kumar / pass1234)
def login(username, password):
    r = requests.post(BASE_LOGIN, json={"username": username, "password": password})
    if r.ok:
        return r.json()
    print("Login failed:", r.text)
    return None

def stream_chat(sessionId, message):
    print("\nUser:", message)
    resp = requests.post(BASE_CHAT, json={"message": message, "sessionId": sessionId}, stream=True)
    full = ""
    try:
        for chunk in resp.iter_content(chunk_size=1024):
            if chunk:
                txt = chunk.decode('utf-8')
                full += txt
        print("Agent:", full)
        return full
    except Exception as e:
        print("Error streaming:", e)
        return None

if __name__ == "__main__":
    info = login("rajesh.kumar", "pass1234")
    if not info:
        print("Please seed DB and ensure user exists (rajesh.kumar / pass1234)")
        exit(1)
    sessionId = info.get("sessionId")
    # test empathy
    stream_chat(sessionId, "I am so frustrated! My refund still hasn't arrived and it's been weeks!")
    # test knowledge base
    stream_chat(sessionId, "I bought the subscription through the App Store. Can you refund me?")
    # test context recall from KB
    stream_chat(sessionId, "Wait, how long did you say it takes for normal refunds?")
