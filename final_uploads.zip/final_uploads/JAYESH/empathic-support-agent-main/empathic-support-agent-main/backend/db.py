# backend/db.py
import os
import sqlite3
from sqlite3 import Connection
from contextlib import closing
from dotenv import load_dotenv
import json
from typing import List, Dict, Optional

load_dotenv()

DEFAULT_DB_PATH = os.path.join("backend", "bunny.db")
DB_URL = os.getenv("DATABASE_URL", f"sqlite:///{DEFAULT_DB_PATH}")

if DB_URL.startswith("sqlite:///"):
    DB_PATH = DB_URL.replace("sqlite:///", "", 1)
elif DB_URL.startswith("sqlite://"):
    DB_PATH = DB_URL.replace("sqlite://", "", 1)
else:
    DB_PATH = DB_URL

DB_PATH = os.path.expanduser(DB_PATH)
db_dir = os.path.dirname(DB_PATH)
if db_dir and not os.path.exists(db_dir):
    try:
        os.makedirs(db_dir, exist_ok=True)
    except Exception:
        pass


def get_conn() -> Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """
    Ensure essential app-specific tables exist and perform lightweight migrations:
    - sessions table for app sessions
    - add password_hash column to customers if missing
    """
    conn = get_conn()
    with closing(conn):
        conn.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT UNIQUE,
            customer_id TEXT,
            data TEXT,
            last_active TEXT DEFAULT CURRENT_TIMESTAMP
        );
        """)
        conn.commit()

        # Add password_hash column to customers if missing
        try:
            cur = conn.execute("PRAGMA table_info(customers)")
            cols = [r["name"] for r in cur.fetchall()]
            if "password_hash" not in cols:
                conn.execute("ALTER TABLE customers ADD COLUMN password_hash TEXT")
                conn.commit()
        except Exception:
            # ignore migration errors
            pass


# ---------------- Customer helpers ----------------
def get_customer_by_phone(phone: str) -> Optional[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM customers WHERE phone_number = ?", (phone,))
    row = cur.fetchone()
    return dict(row) if row else None


def get_customer_by_id(customer_id: int) -> Optional[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM customers WHERE customer_id = ?", (customer_id,))
    row = cur.fetchone()
    return dict(row) if row else None


def create_customer(phone_number: str, full_name: str = None, email: str = None,
                    region_pincode: str = None, password_hash: str = None) -> int:
    conn = get_conn()
    with conn:
        cur = conn.execute(
            """INSERT INTO customers (phone_number, full_name, email, region_pincode, password_hash, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, datetime('now'), datetime('now'))""",
            (phone_number, full_name, email, region_pincode, password_hash)
        )
        return cur.lastrowid


def update_customer_password(customer_id: int, password_hash: str):
    conn = get_conn()
    with conn:
        conn.execute("UPDATE customers SET password_hash = ?, updated_at = datetime('now') WHERE customer_id = ?",
                     (password_hash, customer_id))


# ---------------- Plans & services ----------------
def get_plan_by_plan_id(plan_id) -> Optional[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM plans WHERE plan_id = ?", (plan_id,))
    r = cur.fetchone()
    return dict(r) if r else None


def get_active_service_for_customer(customer_id) -> Optional[Dict]:
    conn = get_conn()
    cur = conn.execute("""
      SELECT cs.*, p.plan_name, p.data_limit_gb, p.monthly_fee
      FROM customer_services cs
      LEFT JOIN plans p ON cs.plan_id = p.plan_id
      WHERE cs.customer_id = ? AND (cs.status = 'active' OR cs.status IS NULL)
      ORDER BY cs.activation_date DESC
      LIMIT 1
    """, (customer_id,))
    r = cur.fetchone()
    return dict(r) if r else None


# ---------------- Sessions (app sessions) ----------------
def create_session(session_id: str, customer_id: int, data: dict = None):
    conn = get_conn()
    with conn:
        conn.execute("INSERT OR REPLACE INTO sessions (session_id, customer_id, data, last_active) VALUES (?, ?, ?, datetime('now'))",
                     (session_id, customer_id, json.dumps(data) if data else None))


def get_session(session_id: str) -> Optional[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM sessions WHERE session_id = ?", (session_id,))
    r = cur.fetchone()
    return dict(r) if r else None


def delete_session(session_id: str):
    conn = get_conn()
    with conn:
        conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))


# ---------------- Chat sessions & messages ----------------
def create_chat_session(customer_id: int) -> int:
    conn = get_conn()
    with conn:
        cur = conn.execute("INSERT INTO chat_sessions (customer_id, started_at) VALUES (?, datetime('now'))",
                           (customer_id,))
        return cur.lastrowid


def end_chat_session(chat_session_pk_id: int):
    conn = get_conn()
    with conn:
        conn.execute("UPDATE chat_sessions SET ended_at = datetime('now') WHERE session_id = ?",
                     (chat_session_pk_id,))


def insert_chat_message(session_id_db: int, sender_type: str, message_text: str, sentiment_score: float = None) -> int:
    conn = get_conn()
    with conn:
        cur = conn.execute(
            "INSERT INTO chat_messages (session_id, sender_type, message_text, sentiment_score, created_at) VALUES (?, ?, ?, ?, datetime('now'))",
            (session_id_db, sender_type, message_text, sentiment_score)
        )
        return cur.lastrowid


def get_chat_history_for_session(session_id_db: int) -> List[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM chat_messages WHERE session_id = ? ORDER BY message_id ASC", (session_id_db,))
    return [dict(r) for r in cur.fetchall()]


def get_recent_chat_sessions(customer_id: int, limit: int = 3) -> List[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM chat_sessions WHERE customer_id = ? ORDER BY started_at DESC LIMIT ?", (customer_id, limit))
    return [dict(r) for r in cur.fetchall()]


# ---------------- Tickets ----------------
def get_open_tickets(customer_id: int) -> List[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM tickets WHERE customer_id = ? AND status IN ('open','pending') ORDER BY created_at DESC", (customer_id,))
    return [dict(r) for r in cur.fetchall()]


def get_recent_tickets(customer_id: int, limit: int = 5) -> List[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM tickets WHERE customer_id = ? ORDER BY created_at DESC LIMIT ?", (customer_id, limit))
    return [dict(r) for r in cur.fetchall()]


# ---------------- Transactions ----------------
def get_recent_transactions(customer_id: int, limit: int = 5) -> List[Dict]:
    conn = get_conn()
    cur = conn.execute("SELECT * FROM transactions WHERE customer_id = ? ORDER BY timestamp DESC LIMIT ?", (customer_id, limit))
    return [dict(r) for r in cur.fetchall()]


# ---------------- Outages ----------------
def get_outages_by_pincode(pincode: str, recent_hours: int = 72) -> List[Dict]:
    """
    Fetch outages in the same pincode. recent_hours parameter optional.
    """
    conn = get_conn()
    # For simplicity, filter by region_pincode matching pincode
    cur = conn.execute("SELECT * FROM outages WHERE region_pincode = ? ORDER BY reported_at DESC", (pincode,))
    return [dict(r) for r in cur.fetchall()]


# ---------------- Utility ----------------
def list_tables() -> List[str]:
    conn = get_conn()
    cur = conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
    return [r["name"] for r in cur.fetchall()]
