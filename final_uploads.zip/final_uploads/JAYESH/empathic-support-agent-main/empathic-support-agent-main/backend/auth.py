# backend/auth.py
import os
import hashlib
import binascii
from typing import Tuple

PBKDF2_ITERATIONS = int(os.getenv("PBKDF2_ITERATIONS", "180000"))
SALT_BYTES = int(os.getenv("SALT_BYTES", "16"))


def generate_salt() -> str:
    return binascii.hexlify(os.urandom(SALT_BYTES)).decode()


def hash_password(password: str, salt: str = None) -> str:
    if salt is None:
        salt = generate_salt()
    pwd = password.encode("utf-8")
    dk = hashlib.pbkdf2_hmac("sha256", pwd, salt.encode("utf-8"), PBKDF2_ITERATIONS)
    hashed = binascii.hexlify(dk).decode()
    return f"{salt}${hashed}"


def check_password(password: str, stored: str) -> bool:
    if not stored or "$" not in stored:
        return False
    salt, stored_hash = stored.split("$", 1)
    pwd = password.encode("utf-8")
    dk = hashlib.pbkdf2_hmac("sha256", pwd, salt.encode("utf-8"), PBKDF2_ITERATIONS)
    hashed = binascii.hexlify(dk).decode()
    return hashed == stored_hash
