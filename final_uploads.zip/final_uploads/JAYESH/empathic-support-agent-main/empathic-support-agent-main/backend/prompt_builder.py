# backend/prompt_builder.py
import json
from typing import Dict, List, Optional

def summarize_chat_history(chat_history: List[Dict], max_msgs: int = 50) -> str:
    """
    Turn chat history rows into a compact string for the LLM.
    We include sender_type and truncated content.
    """
    parts = []
    for msg in chat_history[-max_msgs:]:
        sender = msg.get("sender_type", "user")
        text = msg.get("message_text", "")
        # truncate long texts
        if len(text) > 400:
            text = text[:400] + "...[truncated]"
        parts.append(f"[{sender}] {text}")
    return "\n".join(parts)


def build_prompt(user_message: str, user_info: Dict, sentiment: Dict, kb_context: Optional[str] = None, chat_history: Optional[List[Dict]] = None) -> str:
    """
    Build a system+user prompt string that provides:
     - brief system instructions (empathy + telecom policy)
     - customer context (profile, plan, usage, churn risk)
     - outages, tickets, transactions summary
     - chat history (entire ongoing session - H2)
     - user message as the immediate task
    """

    system_instructions = (
        "You are an empathic customer-support assistant for a telecom provider. "
        "Be concise, compassionate, clear and provide actionable steps. "
        "When giving troubleshooting steps assume user may be non-technical. "
        "If the answer requires account-specific details, reference them but never reveal sensitive data (e.g., full phone numbers, exact billing card numbers). "
        "When suggesting actions, include one immediate troubleshooting step, one intermediate step, and an escalation path if unresolved."
    )

    # Customer context
    profile_lines = []
    if user_info:
        profile_lines.append(f"Customer name: {user_info.get('name') or 'Unknown'}")
        profile_lines.append(f"Phone (masked): {mask_phone(user_info.get('phone_number'))}")
        profile_lines.append(f"Region / Pincode: {user_info.get('region_pincode') or 'Unknown'}")
        if user_info.get('plan_name'):
            profile_lines.append(f"Active plan: {user_info.get('plan_name')} (id: {user_info.get('plan_id')})")
            profile_lines.append(f"Data used: {user_info.get('data_used_gb') or 'N/A'} GB of {user_info.get('data_limit_gb') or 'N/A'} GB")
        if user_info.get('account_status'):
            profile_lines.append(f"Account status: {user_info.get('account_status')}")
        if user_info.get('ltv_score') is not None:
            profile_lines.append(f"LTV score: {user_info.get('ltv_score')}, retention risk: {user_info.get('retention_risk_score')}")
    profile_block = "\n".join(profile_lines)

    # KB context
    kb_block = f"KnowledgeBase: {kb_context}" if kb_context else ""

    # Tickets & transactions: these are expected to be inserted into user_info as lists (if present)
    tickets = user_info.get("tickets_summary") if user_info else None
    txns = user_info.get("transactions_summary") if user_info else None
    outages = user_info.get("outages_summary") if user_info else None

    tickets_block = ""
    if tickets:
        tickets_block = "Open tickets summary:\n" + "\n".join([f"- {t.get('ticket_id') or t.get('id')}: {t.get('subject') or t.get('issue_summary')}" for t in tickets[:5]])

    tx_block = ""
    if txns:
        tx_block = "Recent transactions:\n" + "\n".join([f"- {t.get('transaction_id') or t.get('id')}: {t.get('transaction_type')} {t.get('amount')}" for t in txns[:5]])

    outage_block = ""
    if outages:
        outage_block = "Recent outages in customer's area:\n" + "\n".join([f"- {o.get('outage_id') or o.get('id')}: {o.get('description') or o.get('summary')}" for o in outages[:5]])

    # Chat history (H2: entire ongoing session) - expect chat_history parameter
    history_block = ""
    if chat_history:
        history_block = "Current session chat history:\n" + summarize_chat_history(chat_history, max_msgs=200)

    sentiment_line = f"Detected sentiment: {sentiment.get('label','unknown')} (score: {sentiment.get('score')})" if sentiment else ""

    # Compose final prompt
    prompt_parts = [
        "===SYSTEM INSTRUCTIONS===",
        system_instructions,
        "",
        "===CUSTOMER CONTEXT===",
        profile_block,
        "",
        tickets_block,
        tx_block,
        outage_block,
        "",
        "===KB===",
        kb_block,
        "",
        "===SENTIMENT===",
        sentiment_line,
        "",
        "===CHAT HISTORY===",
        history_block,
        "",
        "===USER MESSAGE===",
        user_message,
        "",
        "===ASSISTANT INSTRUCTIONS===",
        (
            "Answer the user's message directly, using the context above. If the issue can be resolved with steps, "
            "list them and include suggested checks (e.g., reboot router, check cables, check outage maps). "
            "If escalation is needed, provide the exact ticket creation steps and the next best action. "
            "Keep the reply under 400 words."
        )
    ]

    return "\n".join([p for p in prompt_parts if p is not None])


def mask_phone(phone: str) -> str:
    if not phone:
        return "unknown"
    s = str(phone)
    if len(s) <= 4:
        return "***"
    # keep last 4 digits
    return "***-***-" + s[-4:]
