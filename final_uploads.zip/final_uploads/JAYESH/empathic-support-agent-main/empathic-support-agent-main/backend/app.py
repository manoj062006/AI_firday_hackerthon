# backend/app.py
import os
import json
from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()
from backend.db import init_db, create_customer, get_customer_by_phone, create_session, get_session, get_customer_by_id, get_active_service_for_customer, insert_chat_message, create_chat_session
from backend import models
from backend.scrubber import scrub_output
from backend.knowledge_base import search_knowledge_base
from backend.auth import hash_password, check_password

# Initialize DB (and run migrations if needed)
init_db()

app = Flask(__name__)
CORS(app)

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json or {}
    phone = data.get('phone_number') or data.get('phone') or data.get('username')
    password = data.get('password')
    full_name = data.get('name') or data.get('full_name')
    email = data.get('email')
    region = data.get('region_pincode')

    if not phone or not password:
        return jsonify({"error": "phone_number and password are required"}), 400

    existing = get_customer_by_phone(phone)
    if existing:
        return jsonify({"error": "phone number already registered"}), 400

    pwd_hash = hash_password(password)
    try:
        new_id = create_customer(phone_number=phone, full_name=full_name, email=email, region_pincode=region, password_hash=pwd_hash)
    except Exception as e:
        return jsonify({"error": f"failed to create customer: {e}"}), 500

    # Create session for the new customer
    session_id = "sess_" + os.urandom(8).hex()
    create_session(session_id, new_id)

    return jsonify({"success": True, "customer_id": new_id, "name": full_name, "sessionId": session_id})


@app.route('/api/login', methods=['POST'])
def login():
    data = request.json or {}
    phone = data.get('phone_number') or data.get('phone') or data.get('username')
    password = data.get('password')
    if not phone or not password:
        return jsonify({"error": "phone_number and password required"}), 400

    user = get_customer_by_phone(phone)
    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    stored_hash = user.get('password_hash') or ""
    if not check_password(password, stored_hash):
        return jsonify({"error": "Invalid credentials"}), 401

    session_id = "sess_" + os.urandom(8).hex()
    create_session(session_id, user['customer_id'])
    return jsonify({"success": True, "customer_id": user['customer_id'], "name": user.get('full_name'), "sessionId": session_id})


@app.route('/api/me', methods=['GET'])
def me():
    session_id = request.headers.get('X-Session-Id') or request.args.get('sessionId')
    if not session_id:
        return jsonify({"error":"no session"}), 401
    sess = get_session(session_id)
    if not sess:
        return jsonify({"error":"invalid session"}), 401
    customer = get_customer_by_id(sess['customer_id'])
    if not customer:
        return jsonify({"error":"user not found"}), 404
    return jsonify({"user": customer})


@app.route('/api/reset', methods=['POST'])
def reset():
    data = request.json or {}
    session_id = data.get('sessionId')
    if session_id:
        delete_session = None
        try:
            # lightweight deletion
            from backend.db import delete_session
            delete_session(session_id)
        except Exception:
            pass
    return jsonify({"status":"cleared"})


@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json or {}
    session_id = data.get("sessionId")
    user_message = (data.get("message") or "").strip()

    if not session_id or not user_message:
        return jsonify({"error":"Missing message or sessionId"}), 400

    # resolve session -> customer
    sess = get_session(session_id)
    if not sess:
        return jsonify({"error":"Invalid session"}), 401
    customer = get_customer_by_id(sess['customer_id'])
    if not customer:
        return jsonify({"error":"Customer not found"}), 404

    # sentiment
    from backend.sentiment import detect as detect_sentiment
    sentiment = detect_sentiment(user_message)

    # knowledge base
    kb_context = search_knowledge_base(user_message)

    # user_info: pull plan/service
    service = None
    if customer.get('customer_id'):
        service = get_active_service_for_customer(customer['customer_id'])

    user_info = {
        "customer_id": customer.get('customer_id'),
        "phone_number": customer.get('phone_number'),
        "name": customer.get('full_name'),
        "email": customer.get('email'),
        "region_pincode": customer.get('region_pincode'),
        "ltv_score": customer.get('ltv_score'),
        "mcv_score": customer.get('mcv_score'),
        "retention_risk_score": customer.get('retention_risk_score'),
        "plan_id": service.get('plan_id') if service else None,
        "plan_name": service.get('plan_name') if service else None,
        "data_used_gb": service.get('data_used_gb') if service else None,
        "data_limit_gb": service.get('data_limit_gb') if service else None,
        "account_status": service.get('status') if service else None
    }

    # persist chat session/message (create chat_sessions entry and message)
    try:
        chat_session_id = create_chat_session(customer['customer_id'])
        insert_chat_message(chat_session_id, "customer", user_message, sentiment.get('score') if sentiment else None)
    except Exception:
        # ignore persistence errors but continue
        chat_session_id = None

    # build prompt
    from backend.prompt_builder import build_prompt
    prompt_text = build_prompt(user_message=user_message, user_info=user_info, sentiment=sentiment, kb_context=kb_context)

    # generate response from premium LLM
    def generate():
        try:
            meta = json.dumps({"sentiment": sentiment.get('label'), "score": sentiment.get('score')})
            yield f"__META__:{meta}\n"

            resp = models.run_premium(prompt_text, stream=False)
            if not isinstance(resp, str):
                resp = str(resp)
            resp = scrub_output(resp, user_info)

            # persist bot message
            try:
                if chat_session_id:
                    insert_chat_message(chat_session_id, "agent", resp, None)
            except Exception:
                pass

            yield resp

        except Exception as e:
            yield (
                "I'm really sorry — I'm having a bit of trouble reaching the system right now. "
                "Please try again in a moment, and I'll be right here to help you."
            )

    return Response(stream_with_context(generate()), mimetype='text/plain')


if __name__ == "__main__":
    app.run(debug=True, port=int(os.getenv("PORT", 5000)))
