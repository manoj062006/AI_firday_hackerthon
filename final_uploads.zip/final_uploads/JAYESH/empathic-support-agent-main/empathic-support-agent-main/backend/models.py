# backend/models.py
import os
import httpx
from dotenv import load_dotenv
load_dotenv()

MODEL_PROVIDER = "premium"
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o" if os.getenv("OPENAI_MODEL") is None else os.getenv("OPENAI_MODEL"))
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")


def run_premium(prompt_text: str, stream=False) -> str:
    """
    Simple OpenAI-compatible chat completion via HTTPX.
    Returns string reply.
    """
    if not OPENAI_API_KEY:
        return "[MODEL ERROR] Missing OPENAI_API_KEY in .env"

    url = f"{OPENAI_BASE_URL.rstrip('/')}/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": OPENAI_MODEL,
        "messages": [
            {"role": "system", "content": ""},
            {"role": "user", "content": prompt_text}
        ],
        "max_tokens": 800
    }

    try:
        with httpx.Client(verify=False, timeout=30.0) as client:
            r = client.post(url, json=payload, headers=headers)
            r.raise_for_status()
            data = r.json()
    except Exception as e:
        return f"[MODEL ERROR] Premium call failed: {e}"

    try:
        # OpenAI-style extraction
        return data["choices"][0]["message"]["content"]
    except Exception:
        return str(data)
