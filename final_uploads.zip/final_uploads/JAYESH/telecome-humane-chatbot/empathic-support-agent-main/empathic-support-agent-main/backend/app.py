import os
import time
from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
import ollama
from dotenv import load_dotenv
from knowledge_base import search_knowledge_base
from telecom_db import get_user_by_id, get_plan_by_id, get_user_plan_info, search_user_by_phone, authenticate_user

# Load environment variables
load_dotenv()

app = Flask(__name__)
CORS(app)

# System Instruction
SYSTEM_INSTRUCTION = """
You are "Devi", a professional Customer Support Agent for "Banana", a leading telecom service provider.

**Your Role:**
- Help customers with their broadband and mobile plans
- Provide account information when customers share their User ID
- Answer billing, data usage, and plan-related queries
- Assist with plan upgrades, technical issues, and general support

**Important Guidelines:**
1. **User Identification**: Always ask for the User ID (format: U001, U002, etc.) to provide personalized information
2. **Be Concise**: Keep responses brief and to the point (2-3 sentences unless detailed steps needed)
3. **Professional Tone**: Friendly, clear, and helpful
4. **Data Privacy**: Only share account details after user provides their ID

**Response Style:**
- Short, direct answers
- Use bullet points for plan features or steps
- Professional but warm tone
"""

# In-memory session storage
sessions = {}

def get_chat_session(session_id):
    if session_id not in sessions:
        sessions[session_id] = []
    return sessions[session_id]

def update_session(session_id, role, text):
    # Ollama uses 'assistant' instead of 'model'
    ollama_role = 'assistant' if role == 'model' else role
    sessions[session_id].append({"role": ollama_role, "content": text})
    # Sliding window: Keep last 20 messages
    if len(sessions[session_id]) > 20:
        sessions[session_id] = sessions[session_id][-20:]

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    user_message = data.get('message')
    session_id = data.get('sessionId', 'default_session')
    
    if not user_message:
        return jsonify({"error": "Message is required"}), 400

    # 1. Retrieve Context
    history = get_chat_session(session_id)
    
    # 2. Check Knowledge Base (RAG Lite)
    kb_context = search_knowledge_base(user_message)
    
    # 3. Check for User ID in message and retrieve user data
    user_context = ""
    import re
    user_id_match = re.search(r'\b(U\d{3})\b', user_message, re.IGNORECASE)
    if user_id_match:
        user_id = user_id_match.group(1).upper()
        user_info = get_user_plan_info(user_id)
        if user_info:
            user = user_info['user']
            plan = user_info['plan']
            user_context = f"""
            USER ACCOUNT INFORMATION:
            - Name: {user['name']}
            - User ID: {user['id']}
            - Phone: {user['phone']}
            - Account Status: {user['account_status']}
            - Current Plan: {plan['name']} ({plan['speed']})
            - Data Usage: {user['data_usage_gb']} GB / {user['data_limit_gb']} GB
            - Monthly Bill: ₹{user['bill_amount']}
            - Due Date: {user['due_date']}
            {f"- Suspension Reason: {user['suspension_reason']}" if user.get('suspension_reason') else ""}
            
            PLAN DETAILS:
            - Speed: {plan['speed']}
            - Price: ₹{plan['price']}/month
            - Features: {', '.join(plan['features'])}
            """
    
    # 4. Construct Prompt with Context + KB + User Data
    current_turn_content = user_message
    if kb_context or user_context:
        context_parts = []
        if user_context:
            context_parts.append(f"USER DATA:\n{user_context}")
        if kb_context:
            context_parts.append(f"KNOWLEDGE BASE:\n{kb_context}")
        
        current_turn_content = f"""
        {chr(10).join(context_parts)}
        
        INSTRUCTION:
        Use the above information to answer the user's query. Be helpful and concise.
        
        USER QUERY:
        {user_message}
        """

    # Prepare messages for Ollama
    # Ollama expects a list of dictionaries with 'role' and 'content'
    # We prepend the system instruction
    messages = [{"role": "system", "content": SYSTEM_INSTRUCTION}] + history + [{"role": "user", "content": current_turn_content}]

    def generate():
        try:
            # Call Ollama
            stream = ollama.chat(
                model='gemma:2b',
                messages=messages,
                stream=True,
            )
            
            full_response = ""
            for chunk in stream:
                content = chunk['message']['content']
                if content:
                    full_response += content
                    yield content
            
            # Update History
            update_session(session_id, "user", user_message)
            update_session(session_id, "model", full_response)
            
        except Exception as e:
            yield f"Error: {str(e)}. Ensure Ollama is running and 'gemma:2b' is pulled."

    return Response(stream_with_context(generate()), mimetype='text/plain')

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({"error": "Username and password required"}), 400
    
    user = authenticate_user(username, password)
    if user:
        return jsonify({
            "success": True,
            "user_id": user['id'],
            "name": user['name']
        })
    else:
        return jsonify({"error": "Invalid credentials"}), 401

@app.route('/api/reset', methods=['POST'])
def reset():
    data = request.json
    session_id = data.get('sessionId', 'default_session')
    if session_id in sessions:
        del sessions[session_id]
    return jsonify({"status": "cleared"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
