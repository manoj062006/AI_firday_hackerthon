
import requests
import json
import time

BASE_URL = "http://localhost:5000/api/chat"
SESSION_ID = "test_session_123"

def test_chat(message, expected_keywords=None, description=""):
    print(f"\n--- {description} ---")
    print(f"User: {message}")
    
    start_time = time.time()
    try:
        response = requests.post(
            BASE_URL, 
            json={"message": message, "sessionId": SESSION_ID},
            stream=True
        )
        
        full_response = ""
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                full_response += chunk.decode('utf-8')
        
        end_time = time.time()
        latency = end_time - start_time
        
        print(f"Agent: {full_response}")
        print(f"Latency: {latency:.2f}s")
        
        if expected_keywords:
            missing = [k for k in expected_keywords if k.lower() not in full_response.lower()]
            if missing:
                print(f"[FAIL] Missing keywords: {missing}")
            else:
                print("[PASS] Keywords found.")
        else:
            print("[PASS] (No keyword check)")
            
        return full_response
        
    except Exception as e:
        print(f"[ERROR] {e}")
        return None

# 1. Test Empathy
test_chat(
    "I am so frustrated! My refund still hasn't arrived and it's been weeks!", 
    expected_keywords=["understand", "frustrat"], 
    description="Testing Empathy for Angry User"
)

# 2. Test Knowledge Base (RAG)
test_chat(
    "I bought the subscription through the App Store. Can you refund me?", 
    expected_keywords=["third-party", "platform", "cannot"], 
    description="Testing Knowledge Base (Refund Policy)"
)

# 3. Test Context
test_chat(
    "Wait, how long did you say it takes for normal refunds?", 
    expected_keywords=["5-10", "business days"], 
    description="Testing Context (Recall from KB)"
)
