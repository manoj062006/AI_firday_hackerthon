import datetime
import sqlite3


def register_new_customer(phone_number: str, full_name: str, email: str, region_pincode: str) -> str:
    """
    Useful for registering a new customer into the database. 
    It assigns a new customer ID, sets initial scores (LTV, MCV, Risk) to 0, 
    and logs the current creation and update timestamps.
    Input parameters must include a 10-digit phone number, full name, email, and a region pincode.
    """
    try:
        print("to connect")
        # Use the same database path as the existing tool for consistency
        conn = sqlite3.connect('data/bunny.db')
        cursor = conn.cursor()
        print(" connection done ")
        # 1. Find the current maximum customer_id and determine the next ID
        # The first time this runs, MAX(customer_id) might be NULL, so we coalesce it to 0.
        # We assume customer_id is a numeric type for MAX() to work correctly.
        # Note: In a real-world application, this primary key generation logic 
        # should use an AUTOINCREMENT feature for safety and concurrency.
        cursor.execute("SELECT MAX(CAST(customer_id AS INTEGER)) FROM customers")
        max_id = cursor.fetchone()[0]
        print("selection done")
        # If max_id is None (empty table), start with 1, otherwise increment
        new_customer_id = (max_id if max_id is not None else 0) + 1
        
        # 2. Define default values
        ltv_score = 0
        mcv_score = 0
        retention_risk_score = 100
        
        # Get the current time in the format SQLite's datetime('now') uses
        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # 3. Prepare and execute the INSERT statement
        insert_query = """
        INSERT INTO customers 
        (customer_id, phone_number, full_name, email, region_pincode, 
         ltv_score, mcv_score, retention_risk_score, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        cursor.execute(insert_query, (
            str(new_customer_id), # Ensure ID is stored as text/string if the column is TEXT
            phone_number,
            full_name,
            email,
            region_pincode,
            ltv_score,
            mcv_score,
            retention_risk_score,
            current_time,
            current_time
        ))
        print("insert done")
        # 4. Commit changes and close
        conn.commit()
        print("commit done")
        conn.close()
        
        return f"Successfully registered new customer {full_name} with ID: {new_customer_id}."

    except sqlite3.IntegrityError as e:
        # Catch cases where the phone_number might already exist if it has a UNIQUE constraint
        return f"Registration Error: A customer with phone number {phone_number} may already exist. Details: {e}"
    except Exception as e:
        return f"Database Error during registration: {e}"

a=register_new_customer(phone_number="7299111112", full_name="manoj", email= "mm@gmail.com", region_pincode="600001")

print(a)
