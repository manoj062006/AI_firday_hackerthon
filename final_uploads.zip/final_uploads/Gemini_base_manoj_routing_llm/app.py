import streamlit as st
import time
from brain import get_agent_executor
#from brain_orginal import get_agent_executor
# --- Page Config ---
st.set_page_config(page_title="AirComm Assist", page_icon="🔴")

# --- Custom CSS for Airtel Look ---
st.markdown("""
<style>
    .stApp {
        background-color: #f5f5f5;
    }
    .stChatMessage {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    .stChatMessage[data-testid="stChatMessageUser"] {
        background-color: #ffebee; 
    }
    h1 {
        color: #e40000; /* AirComm Red */
    }
</style>
""", unsafe_allow_html=True)

# --- Initialize Session State ---
if "messages" not in st.session_state:
    st.session_state.messages = []
    # Initial Greeting
    st.session_state.messages.append({
        "role": "assistant", 
        "content": "Hi there! I'm sridevi from Aircomm. ❤️ \n\nHow can I help you with your connection or plans today?"
    })

if "agent" not in st.session_state:
    st.session_state.agent = get_agent_executor()

# --- Sidebar ---
with st.sidebar:
    st.image("https://upload.wikimedia.org/wikipedia/commons/b/bd/Airtel_Logo.svg", width=150)
    st.markdown("### Debug Tools")
    st.info("System Running with LLMs")
    st.markdown("---")
    st.markdown("**Test Accounts:**")
    st.code("Ph: 9876543210 (Rahul)")
    st.code("Ph: 1234567890 (Amit)")
    st.markdown("**Test Pincode:**")
    st.code("560100 (Outage Active)")

# --- Chat Interface ---
st.title("Aircomm Genius Support")

# Display History
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Handle User Input
if prompt := st.chat_input("Type your query here..."):
    # 1. Add user message to state
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # 2. Generate Response
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        
        # UI "Thinking" indicator
        with st.spinner("Sridevi is typing..."):
            try:
                # Call the Agent
                raw_response = st.session_state.agent.invoke({"input": prompt})
                response_text = raw_response['output']
                
                # Humanize: Simulate typing speed
                display_text = ""
                for char in response_text:
                    display_text += char
                    message_placeholder.markdown(display_text + "▌")
                    time.sleep(0.01) # Faster typing speed
                
                message_placeholder.markdown(display_text)
                
            except Exception as e:
                error_msg = e
                
                message_placeholder.markdown(error_msg)
                response_text = error_msg

    # 3. Add assistant message to state
    st.session_state.messages.append({"role": "assistant", "content": response_text})