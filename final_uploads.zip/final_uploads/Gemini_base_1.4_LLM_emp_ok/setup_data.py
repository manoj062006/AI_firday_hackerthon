import sqlite3
import os
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

# Ensure data directory exists
if not os.path.exists('data'):
    os.makedirs('data')

# --- 1. Create Mock SQLite User Database ---
def create_user_db():
    print("Creating local SQLite user database...")
    conn = sqlite3.connect('data/users.db')
    c = conn.cursor()
    
    # Create Tables
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (user_id TEXT PRIMARY KEY, name TEXT, plan_name TEXT, 
                  data_balance_gb REAL, bill_due_date TEXT, last_interaction TEXT)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS outages
                 (pincode TEXT, status TEXT, restoration_time TEXT)''')

    # Insert Dummy Data
    users = [
        ('9876543210', 'Rahul Sharma', 'Airtel Infinity 499', 12.5, '2025-10-05', 'Complaint about speed'),
        ('9988776655', 'Priya Singh', 'Prepaid 299', 1.2, 'N/A', 'Recharge query'),
        ('1234567890', 'Amit Patel', 'Black Family Plan', 150.0, '2025-10-10', 'Bill payment')
    ]
    
    outages = [
        ('560100', 'Active Outage', '4:00 PM Today'),
        ('110001', 'Resolved', 'N/A')
    ]

    c.executemany('INSERT OR REPLACE INTO users VALUES (?,?,?,?,?,?)', users)
    c.executemany('INSERT OR REPLACE INTO outages VALUES (?,?,?)', outages)
    
    conn.commit()
    conn.close()
    print("✅ User database created at data/users.db")

# --- 2. Create Mock PDF (Plans) ---
def create_plans_pdf():
    print("Creating Plans PDF...")
    c = canvas.Canvas("data/airtel_plans.pdf", pagesize=letter)
    width, height = letter
    
    text_content = [
        "Airtel Official Tariff Plans 2025",
        "---------------------------------",
        "1. Truly Unlimited 299: 1.5GB/day, Unlimited Calls, 100 SMS/day. Validity: 28 Days.",
        "   Benefits: Apollo 24|7 Circle, Free Hellotunes.",
        "",
        "2. Infinity Postpaid 499: 75GB Data rollover, Unlimited Calls.",
        "   Benefits: Amazon Prime (6 months), Disney+ Hotstar Mobile (1 year).",
        "",
        "3. Airtel Black 1099: Fiber + Landline + DTH.",
        "   Benefits: Netflix Basic, Prime Video, Xstream Premium.",
        "   Speed: Up to 200 Mbps.",
        "",
        "4. International Roaming 2999: 10 days validity, 5GB Data, 100 mins incoming/outgoing.",
        "   Countries covered: USA, UK, UAE, Singapore."
    ]
    
    y = height - 50
    for line in text_content:
        c.drawString(50, y, line)
        y -= 20
    
    c.save()
    print("✅ PDF created at data/airtel_plans.pdf")

# --- 3. Create Troubleshooting TXT ---
def create_troubleshoot_txt():
    print("Creating Troubleshooting Guide...")
    content = """
    Airtel Technical Support SOP - 2025
    
    Issue: Slow Internet Speed
    Step 1: Ask customer to restart the device (Flight mode On/Off).
    Step 2: Check if 'Data Saver' mode is active.
    Step 3: Ask user to check APN settings. Should be 'airtelgprs.com'.
    Step 4: If issue persists, check local tower outages using Pincode.
    
    Issue: No Signal / Emergency Calls Only
    Step 1: Check if SIM is inserted correctly.
    Step 2: Manual Network Selection -> Select Airtel.
    
    Issue: Bill Shock (High Bill)
    Step 1: Check for Value Added Services (VAS) activation.
    Step 2: Check International Roaming usage.
    """
    
    with open("data/troubleshooting.txt", "w") as f:
        f.write(content)
    print("✅ Troubleshooting guide created at data/troubleshooting.txt")

if __name__ == "__main__":
    create_user_db()
    create_plans_pdf()
    create_troubleshoot_txt()