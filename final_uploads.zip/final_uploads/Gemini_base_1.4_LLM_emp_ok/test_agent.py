import sys
import os
# Ensure the current directory is in the path to import brain
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from dotenv import load_dotenv
from brain import get_agent_executor
from requests.exceptions import ConnectionError

def run_test_query(executor, query: str, test_name: str):
    """Runs a single query against the agent and prints the output."""
    print("-" * 50)
    print(f"TEST CASE: {test_name}")
    print(f"QUERY: {query}\n")
    
    # Check if the executor is the error handler (from brain.py connection check)
    if not isinstance(executor, dict) and not hasattr(executor, 'run'):
        print("ERROR: Agent executor is an error function. Skipping test.")
        # Execute the error function to see the error message
        error_output = executor(query)
        print(f"Agent Output (Error Handler): {error_output['output']}")
        return

    try:
        # Run the query
        result = executor.invoke({"input": query})
        
        # The agent uses verbose=True, so we only need the final output here
        print(f"Agent Final Answer:\n{result['output']}")
        
        # Simple check for tool use confirmation (based on expected output)
        if "check_knowledge_base" in test_name and "unlimited" in result['output'].lower():
            print("\n✅ RAG Tool check successful.")
        elif "get_user_details" in test_name and "John Doe" in result['output']:
            print("\n✅ DB User Details check successful.")
        elif "check_network_outage" in test_name and "Active" in result['output']:
            print("\n✅ DB Outage check successful.")
        elif "Ask for info" in test_name and "phone number" in result['output'].lower():
            print("\n✅ Context/Prompt check successful.")
        else:
            print("\n❓ Manual review recommended for output consistency.")

    except ConnectionError:
        print("\n❌ FAILED: Ollama Connection Error. Please ensure the server is running.")
    except Exception as e:
        print(f"\n❌ FAILED: An unexpected error occurred: {e}")
    print("-" * 50 + "\n")


if __name__ == "__main__":
    print("🤖 Initializing Agent Executor from brain.py...")
    
    # Get the agent executor. This includes the Ollama connection check.
    agent_executor = get_agent_executor()
    
    if callable(agent_executor) and not hasattr(agent_executor, 'run'):
        # If the executor is the error function (due to Ollama check failure), print the error and exit
        error_message = agent_executor("")['output']
        print("\n=======================================================")
        print("AGENT INITIALIZATION FAILED:")
        print(error_message)
        print("Please resolve the connection issue before running tests.")
        print("=======================================================")
        sys.exit(1)

    print("\n--- Starting Agent Test Suite ---")

    # --- Test Case 1: Knowledge Base (RAG) ---
    run_test_query(
        agent_executor,
        "What are the benefits of the 499 prepaid plan?",
        "1. RAG Tool: Check Knowledge Base (Plan details)"
    )

    # --- Test Case 2: Database Tool (Success) ---
    run_test_query(
        agent_executor,
        "Can you check the data balance for the number 9876543210?",
        "2. DB Tool: Get User Details (Success)"
    )
    
    # --- Test Case 3: Database Tool (Failure/Not Found) ---
    run_test_query(
        agent_executor,
        "Check the bill due date for the number 1234567890.",
        "3. DB Tool: Get User Details (Failure)"
    )

    # --- Test Case 4: Network Outage Tool (Success) ---
    run_test_query(
        agent_executor,
        "I have a signal problem in pincode 110001. Is there an outage?",
        "4. DB Tool: Check Network Outage (Success)"
    )

    # --- Test Case 5: Network Outage Tool (Failure/No Outage) ---
    run_test_query(
        agent_executor,
        "Why is my signal weak at 110001?",
        "5. DB Tool: Check Network Outage (No Outage)"
    )
    
    # --- Test Case 6: Contextual/Missing Information (Agent must ask) ---
    run_test_query(
        agent_executor,
        "What is my current data balance?",
        "6. Agent Context: Ask for missing information (phone number)"
    )

    print("--- Test Suite Complete ---")