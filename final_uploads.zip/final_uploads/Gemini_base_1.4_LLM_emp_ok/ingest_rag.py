import os
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
# Changed the embedding import
from langchain_community.embeddings import OllamaEmbeddings 
# Removed SSL import, as Ollama handles the network call externally

# Configuration
DATA_PATH = "data/"
DB_PATH = "faiss_db" 

# NOTE: The SSL bypass has been removed as we are now relying on the Ollama CLI 
# for the one-time download of the 'nomic-embed-text' model.

def ingest_data():
    print("🚀 Starting Data Ingestion...")
    
    documents = []
    
    # 1. Load PDF
    if os.path.exists(os.path.join(DATA_PATH, "airtel_plans.pdf")):
        pdf_loader = PyPDFLoader(os.path.join(DATA_PATH, "airtel_plans.pdf"))
        documents.extend(pdf_loader.load())
        print("📄 Loaded PDF Plans")

    # 2. Load TXT
    if os.path.exists(os.path.join(DATA_PATH, "troubleshooting.txt")):
        txt_loader = TextLoader(os.path.join(DATA_PATH, "troubleshooting.txt"))
        documents.extend(txt_loader.load())
        print("📄 Loaded Troubleshooting Text")

    # 3. Split Text (Chunking)
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=100, chunk_overlap=20)
    splits = text_splitter.split_documents(documents)
    print(f"🧩 Split into {len(splits)} chunks")

    # 4. Create Embeddings & Store in FAISS
    # Using Ollama's embedding model (must be pulled first: 'ollama pull nomic-embed-text')
    embedding_func = OllamaEmbeddings(model="nomic-embed-text")
    
    # Create the FAISS index
    vector_db = FAISS.from_documents(
        documents=splits, 
        embedding=embedding_func, 
    )
    
    # Save the index locally
    vector_db.save_local(folder_path=DB_PATH)
    
    print(f"✅ Vector Database built using FAISS and Ollama Embeddings at '{DB_PATH}'")

if __name__ == "__main__":
    ingest_data()