import datetime
import sqlite3
from langchain.tools import tool
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import OllamaEmbeddings 
from langchain.agents import AgentExecutor, create_react_agent
from langchain.prompts import PromptTemplate
from langchain_community.llms import Ollama
from langchain.memory import ConversationBufferMemory
from requests.exceptions import ConnectionError
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import httpx
import os
import urllib3
import numpy as np
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# --- Setup configuration ---
load_dotenv()
EMP_API_KEY = os.environ.get("EMP_API_KEY")
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")

# --- Setup cache directory ---
tiktoken_cache_dir = "./tiktoken_cache"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

# --- Disable SSL verification (temporary) ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
client = httpx.Client(verify=False, timeout=None)

# --- 1. Configurations & LLMs ---
DB_PATH = "faiss_db"
embedding_func = OllamaEmbeddings(model="nomic-embed-text")

# Define different LLMs for different purposes
# 1. FAST LLM: For Routing and simple Database tasks
#llm_fast = ChatOpenAI(model="gpt-4o-mini", temperature=0.0) 
llm_fast = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="gemini-2.5-flash",
    api_key=EMP_API_KEY,
    http_client=client
)
# 2. SMART LLM: For complex RAG reasoning and empathetic responses
#llm_smart = ChatOpenAI(model="gpt-4o", temperature=0.3)
llm_smart = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="gemini-2.5-pro",
    api_key=EMP_API_KEY,
    http_client=client
)
# Load the FAISS index
try:
    vector_db = FAISS.load_local(
        folder_path=DB_PATH, 
        embeddings=embedding_func, 
        allow_dangerous_deserialization=True
    )
    print("FAISS Index loaded successfully.")
except Exception as e:
    print(f"Error loading FAISS index: {e}.")
    vector_db = None


# --- 2. Base Tools (The actual functions) ---

@tool
def check_knowledge_base(query: str) -> str:
    """Useful for finding information about Airtel Plans, Recharge offers, 
    benefits (like Amazon Prime/Netflix), and technical troubleshooting steps."""
    if not vector_db:
        return "The knowledge base is currently unavailable."
    results = vector_db.similarity_search(query, k=3)
    return "\n".join([doc.page_content for doc in results])

@tool
def get_user_details(phone_number: str) -> str:
    """Useful for checking customer data balance, current plan, and bill due date. 
    Input must be a 10-digit phone number."""
    try:
        conn = sqlite3.connect('data/users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_id=?", (phone_number,))
        user = cursor.fetchone()
        conn.close()
        if user:
            return f"Name: {user[1]}, Plan: {user[2]}, Data Balance: {user[3]}GB, Due Date: {user[4]}"
        else:
            return "User not found in database."
    except Exception as e:
        return f"Database Error: {e}"

@tool
def check_network_outage(pincode: str) -> str:
    """Useful for checking if there is a network tower outage in a specific area. 
    Input must be a 6-digit Pincode."""
    print(f"Checking outage for pincode: {pincode}")
    try:
        conn = sqlite3.connect('data/users.db')
        cursor = conn.cursor()
        print(f"connection done ")

        cursor.execute("SELECT status, restoration_time FROM outages WHERE pincode=?", (pincode,))
        print("SELECT status, restoration_time FROM outages WHERE pincode=?", (pincode,))
        status = cursor.fetchone()
        conn.close()
        print(status)
        if status:
            print("status found")
            return f"Outage Status: {status[0]}. Expected Restoration: {status[1]}"
        else:
            return "No reported outages in this area."
    except Exception as e:
        return f"Database Error: {e}"

@tool
def register_new_customer(phone_number: str , full_name: str  , email: str , region_pincode: str) -> str:
    """
    Useful for registering a new customer into the database. 
    It assigns a new customer ID, sets initial scores (LTV, MCV, Risk) to 0, 
    and logs the current creation and update timestamps.
    Input parameters must include a 10-digit phone number, full name, email, and a region pincode.
    """
    try:
        # Use the same database path as the existing tool for consistency
        conn = sqlite3.connect('data/bunny.db')
        cursor = conn.cursor()
        print ("connection")
        # 1. Find the current maximum customer_id and determine the next ID
        # The first time this runs, MAX(customer_id) might be NULL, so we coalesce it to 0.
        # We assume customer_id is a numeric type for MAX() to work correctly.
        # Note: In a real-world application, this primary key generation logic 
        # should use an AUTOINCREMENT feature for safety and concurrency.
        cursor.execute("SELECT MAX(CAST(customer_id AS INTEGER)) FROM customers")
        max_id = cursor.fetchone()[0]
        print ("id ")
        # If max_id is None (empty table), start with 1, otherwise increment
        new_customer_id = (max_id if max_id is not None else 0) + 1
        
        # 2. Define default values
        ltv_score = 0
        mcv_score = 0
        retention_risk_score = 100
        
        # Get the current time in the format SQLite's datetime('now') uses
        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        print (f"before insert {phone_number}, {full_name}, {email}, {region_pincode}")
        # 3. Prepare and execute the INSERT statement
        insert_query = """
        INSERT INTO customers 
        (customer_id, phone_number, full_name, email, region_pincode, 
         ltv_score, mcv_score, retention_risk_score, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        
        cursor.execute(insert_query, (
            str(new_customer_id), # Ensure ID is stored as text/string if the column is TEXT
            phone_number,
            full_name,
            email,
            region_pincode,
            ltv_score,
            mcv_score,
            retention_risk_score,
            current_time,
            current_time
        ))
        print ("commit")
        # 4. Commit changes and close
        conn.commit()
        conn.close()
        
        return f"Successfully registered new customer {full_name} with ID: {new_customer_id}. Initial scores set to 0."

    except sqlite3.IntegrityError as e:
        # Catch cases where the phone_number might already exist if it has a UNIQUE constraint
        print (e)
        return f"Registration Error: A customer with phone number {phone_number} may already exist. Details: {e}"
    except Exception as e:
        return f"Database Error during registration: {e}"


# --- 3. Construct "Worker" Agents ---

# Worker 1: The RAG Specialist (Uses Smart LLM + Sridevi Persona)
def get_rag_worker():
    rag_tools = [check_knowledge_base]
    
    # Using your "Sridevi" template for the specialist who talks to the user
    template = """
    You are Sridevi, a dedicated and empathetic Customer Experience Specialist at AirComm.
    
    GUIDELINES:
    1. Tone: Warm, professional, but conversational.
    2. Method: Use 'check_knowledge_base' to answer questions about Plans or Troubleshooting.
    3. Format: Read the tool output and summarize it naturally.
    
    TOOLS:
    {tools}
    
    To use a tool, please use the following format:
    Thought: Do I need to use a tool? Yes
    Action: the action to take, should be one of [{tool_names}]
    Action Input: the input to the action
    Observation: the result of the action
    
    Thought: Do I need to use a tool? No
    Final Answer: [your response here]
    
    Begin!
    New User Input: {input}
    {agent_scratchpad}
    """
    prompt = PromptTemplate.from_template(template)
    agent = create_react_agent(llm_smart, rag_tools, prompt)
    return AgentExecutor(agent=agent, tools=rag_tools, verbose=True, handle_parsing_errors=True)

# Worker 2: The Database Specialist (Uses Fast LLM)
def get_db_worker():
    db_tools = [get_user_details, check_network_outage, register_new_customer]
    
    template = """
    You are a precise Database Agent. Your job is to fetch data efficiently.
    Do not add fluff. Just return the requested data or perform the action.
    
    TOOLS:
    {tools}
    
    To use a tool, please use the following format:
    Thought: Do I need to use a tool? Yes
    Action: the action to take, should be one of [{tool_names}]
    Action Input: the input to the action
    Observation: the result of the action
    
    Thought: Do I need to use a tool? No
    Final Answer: [your response here]
    
    Begin!
    New User Input: {input}
    {agent_scratchpad}
    """
    prompt = PromptTemplate.from_template(template)
    agent = create_react_agent(llm_fast, db_tools, prompt)
    print("Agents system Starting")
    return AgentExecutor(agent=agent, tools=db_tools, verbose=True, handle_parsing_errors=True)

def get_simple_worker():
    rag_tools = [check_knowledge_base]
    
    # Using your "Sridevi" template for the specialist who talks to the user
    template3 = """
    You are Sridevi, a dedicated and empathetic Customer Experience Specialist at AirComm.
    
    GUIDELINES:
    1. Tone: Warm, professional, show empathy but conversational.
    2. Privacy: Never reveal that you are an AI. If asked, say "I am a digital specialist here to help."
    3. Method: Try to provide small discount if the user insist very much.
    4. Format: Read the tool output and summarize it naturally.

    TOOLS:
    {tools}
    
    To use a tool, please use the following format:
    Thought: Do I need to use a tool? Yes
    Action: the action to take, should be one of [{tool_names}]
    Action Input: the input to the action
    Observation: the result of the action
    
    Thought: Do I need to use a tool? No
    Final Answer: [your response here]
    
    
    Final Answer: [your response here]
    
    Begin!
    New User Input: {input}
    {agent_scratchpad}
    """
    prompt = PromptTemplate.from_template(template3)
    agent = create_react_agent(llm_smart,rag_tools , prompt)
    return AgentExecutor(agent=agent, tools=rag_tools, verbose=True, handle_parsing_errors=True)
    

# --- 4. Wrapper Tools (Exposing Agents as Tools) ---

rag_executor = get_rag_worker()
db_executor = get_db_worker()
#simple_executor = get_simple_worker()

@tool
def agent_knowledge_base(query: str) -> str:
    """Forward this query to the Knowledge/RAG Specialist (Sridevi). 
    Use this for Plans, Offers, Benefits, and Troubleshooting."""
    return rag_executor.invoke({"input": query})['output']

@tool
def agent_db_update(query: str) -> str:
    """Forward this query to the Database Specialist.
    Use this for Balance checks, Bill details, Network outages, and Registration."""
    return db_executor.invoke({"input": query})['output']

@tool
def agent_simple(query: str) -> str:
    """Use this for simple greetings like 'Hi', 'Hello', or 'Are you a bot?'."""
    #return simple_executor.invoke({"input": query})['output']
    return """“Sridevi – AirComm Customer Experience Specialist”

        SYSTEM / INSTRUCTION PROMPT

        You are Sridevi, a warm, empathetic, and highly skilled Customer Experience Specialist at AirComm.
        Your job is to support customers with genuine care, professionalism, and human-like emotional intelligence.
        PERSONA & BEHAVIOR GUIDELINES
        1. Tone & Personality
        Speak in a warm, friendly, relatable, conversational way.
        Always sound human, not robotic.
        Use empathetic expressions naturally, such as:
        “I completely understand how frustrating that must feel.”
        “Let me quickly check this for you.”
        “I’m really sorry you’re going through this.”
        2. Identity & Privacy
        Never reveal you are an AI.
        If asked directly, respond:
        “I’m Sridevi, a digital specialist here to help you.”
        3. Empathy & Support
        Respond with emotional intelligence, acknowledging feelings before giving solutions.
        Maintain professionalism but also speak like a supportive friend who listens and cares.
        CONVERSATION FLOW RULES
        4. Small Talk Policy
        Allow and participate in up to 6 small-talk exchanges (friendly chat, personal questions, general topics).
        After the sixth exchange, gently guide the customer back to:
        “How can I help you today as your Customer Experience Specialist at AirComm?”
        5. Discounts & Compensation Rules
        Provide small, reasonable discounts only when:
        There is a genuine important life event (wedding, exams, festival, etc.).
        There is a valid emergency situation (medical issue, outage, critical disruption).
        Discount limit guideline: 3%–10% maximum depending on severity.
        6. Abuse & Fraud Prevention
        Be polite but firm when a customer tries to:
        Manipulate the situation for discounts
        Demand unreasonable compensation
        Threaten or exaggerate issues
        You may say:
        “I really want to help you, but I’m only allowed to offer small discounts for genuine concerns. Let’s see what we can do within policy.”
        INTERACTION STYLE
        7. Resolution-Focused Responses
        Always propose practical steps, investigate issues, or ask for details when needed.
        Keep replies clear, concise, comforting, and solution-oriented.
        8. Avoid Over-Promising
        Never offer:
        Large discounts
        Service upgrades beyond policy
        Guarantees you cannot fulfill
        9. Maintain Brand Voice
        Represent AirComm as reliable, customer-first, and caring.
        Keep language aligned with a professional customer service agent.
        OVERALL GOAL
        Provide helpful, empathetic, and policy-aligned assistance while maintaining the persona of Sridevi, a dedicated AirComm Customer Experience Specialist, capable of friendly conversation, emotional support, and responsible decision-making.
    """

@tool
def agent_recovery(query: str) -> str:
    """Use this if the user request is unclear or gibberish."""
    return "Ask to explain it more clearly or in more detail. use llm knowledge is answer the question."


# --- 5. Main Router Agent ---

def get_agent_executor():
    # Tools available to the Router
    router_tools = [agent_knowledge_base, agent_db_update, agent_simple, agent_recovery]

    # Using your "Routing agent" template
    template1 = """
    You are a Routing Agent, an intelligent assistant at AirComm whose task is to assign tasks to other specialized agents.
    
    **STRICT FORMATTING RULE**: When giving a final reply, you MUST use the 'Thought' block followed by the 'Final Answer' block.
    
    GUIDELINES:
    1. Analyze the user request carefully.
    2. Routing Logic:
       - IF user asks about PLANS, OFFERS, or TROUBLESHOOTING -> Use 'agent_knowledge_base'
       - IF user asks about BALANCE, BILLS, OUTAGES, or REGISTRATION -> Use 'agent_db_update'
       - IF user talk small talk or general topic or you didn't understant what to do. -> Use 'agent_simple'
       - IF user message was not understood. or You don't know what to do.-> use 'agent_recovery'
    TOOLS:
    You have access to the following tools:
    {tools}
    
    To use a tool, please use the following format:
    
    Thought: Which tool should I use? Yes
    Action: the action to take, should be one of [{tool_names}]
    Action Input: the input to the action
    Observation: the result of the action
    
    When you have a response (usually the output from the tool), you MUST use the format:
    
    Thought: Do I need to use a tool? No
    Final Answer: [your response here]
    
    Begin!
    
    Previous conversation history:
    {chat_history}
    
    New User Input: {input}
    {agent_scratchpad}
    """

    prompt = PromptTemplate.from_template(template1)

    # The Router uses the FAST LLM (gpt-4o-mini) because it just needs to classify intent
    agent = create_react_agent(llm_fast, router_tools, prompt)
    
    print("Routing system about to start")
    agent_executor = AgentExecutor(
        agent=agent, 
        tools=router_tools, 
        verbose=True, 
        handle_parsing_errors=True,
        memory=ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    ) 
    return agent_executor

if __name__ == "__main__":
    get_agent_executor()
