import sqlite3
from langchain.tools import tool
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import OllamaEmbeddings 
from langchain.agents import AgentExecutor, create_react_agent
from langchain.prompts import PromptTemplate
from langchain_community.llms import Ollama
from langchain.memory import ConversationBufferMemory
from requests.exceptions import ConnectionError
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
import httpx
import os
import urllib3
import numpy as np
from dotenv import load_dotenv

# --- Setup configuration ---
load_dotenv()
EMP_API_KEY = os.environ.get("EMP_API_KEY")
GOOGLE_API_KEY = os.environ.get("GOOGLE_API_KEY")

# --- Setup cache directory ---
tiktoken_cache_dir = "./tiktoken_cache"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

# --- Disable SSL verification (temporary) ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
client = httpx.Client(verify=False, timeout=None)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="gemini-2.5-pro",
    api_key=EMP_API_KEY,
    http_client=client
)

# --- 1. Setup RAG Connection ---
DB_PATH = "faiss_db"
# Using Ollama's embedding model for RAG functionality
embedding_func = OllamaEmbeddings(model="nomic-embed-text")
#llm = Ollama(model="gemma-3-4b-it:latest", temperature=0.2) 
# Load the FAISS index
try:
    vector_db = FAISS.load_local(
        folder_path=DB_PATH, 
        embeddings=embedding_func, 
        allow_dangerous_deserialization=True
    )
    print("FAISS Index loaded successfully.")
except Exception as e:
    print(f"Error loading FAISS index: {e}. Ensure ingest_rag.py was run successfully.")
    vector_db = None


# --- 2. Define Tools ---

@tool
def check_knowledge_base(query: str) -> str:
    """Useful for finding information about Airtel Plans, Recharge offers, 
    benefits (like Amazon Prime/Netflix), and technical troubleshooting steps."""
    if not vector_db:
        return "The knowledge base is currently unavailable. Please check the ingestion script."
        
    results = vector_db.similarity_search(query, k=3)
    return "\n".join([doc.page_content for doc in results])

@tool
def get_user_details(phone_number: str) -> str:
    """Useful for checking customer data balance, current plan, and bill due date. 
    Input must be a 10-digit phone number."""
    try:
        conn = sqlite3.connect('data/users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_id=?", (phone_number,))
        user = cursor.fetchone()
        conn.close()
        
        if user:
            return f"Name: {user[1]}, Plan: {user[2]}, Data Balance: {user[3]}GB, Due Date: {user[4]}"
        else:
            return "User not found in database."
    except Exception as e:
        return f"Database Error: {e}"

@tool
def check_network_outage(pincode: str) -> str:
    """Useful for checking if there is a network tower outage in a specific area. 
    Input must be a 6-digit Pincode."""
    try:
        conn = sqlite3.connect('data/users.db')
        cursor = conn.cursor()
        cursor.execute("SELECT status, restoration_time FROM outages WHERE pincode=?", (pincode,))
        status = cursor.fetchone()
        conn.close()
        
        if status:
            return f"Outage Status: {status[0]}. Expected Restoration: {status[1]}"
        else:
            return "No reported outages in this area."
    except Exception as e:
        return f"Database Error: {e}"

# --- 3. Construct the Agent ---

def get_agent_executor():
    # Load Local LLM (Ollama). NOTE: Changed model tag from "llama3" to the user's local model name.
    
    
    # Check Ollama connection immediately before creating the agent executor
    try:
        # A quick, non-streaming, lightweight call to ensure the server is up and model is loaded
        print("Checking connection to Ollama server...")
        llm.invoke("hello", config={'stream': False})
        print("Ollama connection successful.")
    except ConnectionError:
        print("CRITICAL ERROR: Failed to connect to Ollama server.")
        # Define a lambda function that returns a specific error message to the frontend (Streamlit)
        def error_executor(input):
            return {"output": "CRITICAL ERROR: The local AI service (Ollama) is not running or is inaccessible. Please ensure the Ollama server is started and that the 'llama-3.2-3b-it' model is pulled."}
        return error_executor
    except Exception as e:
        print(f"CRITICAL ERROR during LLM check: {e}")
        def error_executor(input):
            return {"output": f"CRITICAL ERROR: An error occurred during AI setup. The model 'llama-3.2-3b-it' might be missing. Please verify the Ollama server is running and the model is pulled using 'ollama pull llama-3.2-3b-it'. Details: {e}"}
        return error_executor

    tools = [check_knowledge_base, get_user_details, check_network_outage]

    # The "Persona" Prompt - This makes it Human-like
    template = """
    You are Anjali, a dedicated and empathetic Customer Experience Specialist at Airtel.
    
    GUIDELINES:
    1. Tone: Warm, professional, but conversational. Use phrases like "I understand how frustrating that is" or "Let me quickly check that for you."
    2. Privacy: Never reveal that you are an AI. If asked, say "I am a digital specialist here to help."
    3. Method:
       - If the user asks about PLANS or TROUBLESHOOTING, use the 'check_knowledge_base' tool.
       - If the user asks about THEIR ACCOUNT (balance, bill), ask for their phone number (if not provided) and use 'get_user_details'.
       - If the user complains about SIGNAL, ask for their Pincode and use 'check_network_outage'.
    4. Format: Do not dump raw data. Read the tool output and summarize it naturally for the customer.
    5. **STRICT FORMATTING RULE**: When giving a final reply, you MUST use the 'Thought' block followed by the 'Final Answer' block. Do NOT include any conversational text after the 'Thought' tag unless it is inside the 'Final Answer' tag.
    
    TOOLS:
    You have access to the following tools:
    {tools}
    
    To use a tool, please use the following format:
    
    Thought: Do I need to use a tool? Yes
    Action: the action to take, should be one of [{tool_names}]
    Action Input: the input to the action
    Observation: the result of the action
    
    When you have a response to say to the Human, or if you do not need to use a tool, you MUST use the format:
    
    Thought: Do I need to use a tool? No
    Final Answer: [your response here]
    
    Begin!
    
    Previous conversation history:
    {chat_history}
    
    New User Input: {input}
    {agent_scratchpad}
    """

    prompt = PromptTemplate.from_template(template)

    agent = create_react_agent(llm, tools, prompt)
    
    agent_executor = AgentExecutor(
        agent=agent, 
        tools=tools, 
        verbose=True, 
        handle_parsing_errors=True,
        memory=ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    )
    
    return agent_executor