/* ============================================================
   MASTER SQLITE DEPLOYMENT SCRIPT - SINGLE FILE
   Safe • Idempotent • Analytics Ready • ML Ready • Archival Ready
============================================================ */

PRAGMA foreign_keys = OFF;

------------------------------------------------------------
-- DROP VIEWS (FIRST)
------------------------------------------------------------
DROP VIEW IF EXISTS vw_monthly_revenue;
DROP VIEW IF EXISTS vw_customer_revenue;
DROP VIEW IF EXISTS vw_mrr;
DROP VIEW IF EXISTS vw_arpu;
DROP VIEW IF EXISTS vw_churned_customers;
DROP VIEW IF EXISTS vw_active_outages;
DROP VIEW IF EXISTS vw_ml_customer_features;
DROP VIEW IF EXISTS vw_ml_routing_features;

------------------------------------------------------------
-- DROP TRIGGERS
------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_tickets_touch;

------------------------------------------------------------
-- DROP INDEXES
------------------------------------------------------------
DROP INDEX IF EXISTS idx_customers_phone;
DROP INDEX IF EXISTS idx_services_customer;
DROP INDEX IF EXISTS idx_transactions_customer;
DROP INDEX IF EXISTS idx_transactions_status_date;
DROP INDEX IF EXISTS idx_tickets_customer_status;
DROP INDEX IF EXISTS idx_outages_service;
DROP INDEX IF EXISTS idx_chat_sessions_customer;
DROP INDEX IF EXISTS idx_rewards_customer;

------------------------------------------------------------
-- DROP ARCHIVE TABLES
------------------------------------------------------------
DROP TABLE IF EXISTS transactions_archive;
DROP TABLE IF EXISTS tickets_archive;
DROP TABLE IF EXISTS chat_sessions_archive;
DROP TABLE IF EXISTS chat_messages_archive;

------------------------------------------------------------
-- DROP BASE TABLES (CHILD → PARENT)
------------------------------------------------------------
DROP TABLE IF EXISTS rewards;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS chat_sessions;
DROP TABLE IF EXISTS outages;
DROP TABLE IF EXISTS tickets;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS customer_services;
DROP TABLE IF EXISTS plans;
DROP TABLE IF EXISTS customers;

------------------------------------------------------------
-- CUSTOMERS
------------------------------------------------------------
CREATE TABLE customers (
    customer_id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone_number TEXT NOT NULL UNIQUE,
    full_name TEXT,
    email TEXT UNIQUE,
    region_pincode TEXT,
    ltv_score REAL NOT NULL DEFAULT 0.00,
    mcv_score REAL NOT NULL DEFAULT 0.00,
    retention_risk_score INTEGER CHECK (retention_risk_score BETWEEN 1 AND 100),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    CHECK (length(phone_number) BETWEEN 10 AND 15)
);

------------------------------------------------------------
-- PLANS
------------------------------------------------------------
CREATE TABLE plans (
    plan_id INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_name TEXT NOT NULL,
    plan_type TEXT CHECK (plan_type IN ('PREPAID','POSTPAID')),
    monthly_fee REAL NOT NULL,
    data_limit_gb REAL,
    created_at TEXT DEFAULT (datetime('now'))
);

------------------------------------------------------------
-- CUSTOMER SERVICES
------------------------------------------------------------
CREATE TABLE customer_services (
    service_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    plan_id INTEGER NOT NULL,
    status TEXT CHECK (status IN ('ACTIVE','SUSPENDED','CANCELLED')),
    start_date TEXT,
    end_date TEXT,
    auto_pay_enabled INTEGER CHECK (auto_pay_enabled IN (0,1)),
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id) REFERENCES plans(plan_id)
);

------------------------------------------------------------
-- TRANSACTIONS
------------------------------------------------------------
CREATE TABLE transactions (
    transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    amount REAL NOT NULL,
    status TEXT CHECK (status IN ('SUCCESS','FAILED','PENDING')),
    payment_method TEXT,
    transaction_date TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

------------------------------------------------------------
-- TICKETS
------------------------------------------------------------
CREATE TABLE tickets (
    ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    service_id INTEGER,
    issue_type TEXT,
    severity_level INTEGER CHECK (severity_level BETWEEN 1 AND 5),
    status TEXT CHECK (status IN ('OPEN','IN_PROGRESS','RESOLVED','CLOSED')),
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES customer_services(service_id)
);

------------------------------------------------------------
-- OUTAGES
------------------------------------------------------------
CREATE TABLE outages (
    outage_id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_id INTEGER,
    region_pincode TEXT,
    severity_level INTEGER CHECK (severity_level BETWEEN 1 AND 5),
    status TEXT CHECK (status IN ('ACTIVE','RESOLVED')),
    reported_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (service_id) REFERENCES customer_services(service_id)
);

------------------------------------------------------------
-- CHAT SESSIONS
------------------------------------------------------------
CREATE TABLE chat_sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    started_at TEXT DEFAULT (datetime('now')),
    ended_at TEXT,
    resolution_status TEXT,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL
);

------------------------------------------------------------
-- CHAT MESSAGES
------------------------------------------------------------
CREATE TABLE chat_messages (
    message_id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER,
    sender_type TEXT CHECK (sender_type IN ('CUSTOMER','BOT','AGENT')),
    message_text TEXT,
    sentiment_score REAL,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (session_id) REFERENCES chat_sessions(session_id) ON DELETE CASCADE
);

------------------------------------------------------------
-- REWARDS
------------------------------------------------------------
CREATE TABLE rewards (
    reward_id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    reward_points INTEGER DEFAULT 0,
    last_updated TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
);

------------------------------------------------------------
-- ARCHIVE TABLES
------------------------------------------------------------
CREATE TABLE transactions_archive AS SELECT *, datetime('now') AS archived_at FROM transactions WHERE 0;
CREATE TABLE tickets_archive AS SELECT *, datetime('now') AS archived_at FROM tickets WHERE 0;
CREATE TABLE chat_sessions_archive AS SELECT *, datetime('now') AS archived_at FROM chat_sessions WHERE 0;
CREATE TABLE chat_messages_archive AS SELECT *, datetime('now') AS archived_at FROM chat_messages WHERE 0;

------------------------------------------------------------
-- INDEXES
------------------------------------------------------------
CREATE INDEX idx_customers_phone ON customers(phone_number);
CREATE INDEX idx_services_customer ON customer_services(customer_id);
CREATE INDEX idx_transactions_customer ON transactions(customer_id);
CREATE INDEX idx_transactions_status_date ON transactions(status, transaction_date);
CREATE INDEX idx_tickets_customer_status ON tickets(customer_id, status);
CREATE INDEX idx_outages_service ON outages(service_id);
CREATE INDEX idx_chat_sessions_customer ON chat_sessions(customer_id);
CREATE INDEX idx_rewards_customer ON rewards(customer_id);

------------------------------------------------------------
-- TRIGGER: AUTO UPDATE TICKETS UPDATED_AT
------------------------------------------------------------
CREATE TRIGGER trg_tickets_touch
AFTER UPDATE ON tickets
FOR EACH ROW
WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE tickets
    SET updated_at = datetime('now')
    WHERE ticket_id = NEW.ticket_id;
END;

------------------------------------------------------------
-- ANALYTICS VIEWS
------------------------------------------------------------

CREATE VIEW vw_monthly_revenue AS
SELECT
    strftime('%Y-%m', transaction_date) AS revenue_month,
    SUM(CASE WHEN status = 'SUCCESS' THEN amount ELSE 0 END) AS total_revenue
FROM transactions
GROUP BY revenue_month;

CREATE VIEW vw_customer_revenue AS
SELECT
    c.customer_id,
    c.full_name,
    SUM(CASE WHEN t.status = 'SUCCESS' THEN t.amount ELSE 0 END) AS lifetime_revenue
FROM customers c
LEFT JOIN transactions t ON c.customer_id = t.customer_id
GROUP BY c.customer_id;

CREATE VIEW vw_mrr AS
SELECT
    strftime('%Y-%m', cs.start_date) AS revenue_month,
    SUM(p.monthly_fee) AS mrr
FROM customer_services cs
JOIN plans p ON cs.plan_id = p.plan_id
WHERE cs.status = 'ACTIVE'
GROUP BY revenue_month;

CREATE VIEW vw_arpu AS
SELECT
    revenue_month,
    total_revenue / NULLIF(active_customers, 0) AS arpu
FROM (
    SELECT
        strftime('%Y-%m', t.transaction_date) AS revenue_month,
        SUM(CASE WHEN t.status = 'SUCCESS' THEN t.amount ELSE 0 END) AS total_revenue,
        COUNT(DISTINCT cs.customer_id) AS active_customers
    FROM transactions t
    LEFT JOIN customer_services cs ON t.customer_id = cs.customer_id
    WHERE cs.status = 'ACTIVE'
    GROUP BY revenue_month
);

CREATE VIEW vw_churned_customers AS
SELECT *
FROM customers
WHERE retention_risk_score >= 80;

CREATE VIEW vw_active_outages AS
SELECT *
FROM outages
WHERE status = 'ACTIVE';

------------------------------------------------------------
-- ✅ REFACTORED ML VIEW: CUSTOMER FEATURES (FAN-OUT SAFE)
------------------------------------------------------------
DROP VIEW IF EXISTS vw_ml_customer_features;

CREATE VIEW vw_ml_customer_features AS
WITH
svc AS (
    SELECT
        customer_id,
        COUNT(*) AS total_services,
        SUM(CASE WHEN status = 'ACTIVE' THEN 1 ELSE 0 END) AS active_services,
        MAX(julianday('now') - julianday(start_date)) AS tenure_days
    FROM customer_services
    GROUP BY customer_id
),
tkt AS (
    SELECT
        customer_id,
        COUNT(*) AS total_tickets,
        AVG(severity_level) AS avg_severity
    FROM tickets
    GROUP BY customer_id
),
txn AS (
    SELECT
        customer_id,
        SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) AS successful_payments,
        SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) AS failed_payments,
        SUM(CASE WHEN status = 'SUCCESS' THEN amount ELSE 0 END) AS total_revenue,
        MAX(julianday('now') - julianday(transaction_date)) AS recency_days
    FROM transactions
    GROUP BY customer_id
)
SELECT
    c.customer_id,
    COALESCE(svc.total_services, 0) AS total_services,
    COALESCE(svc.active_services, 0) AS active_services,
    COALESCE(tkt.total_tickets, 0) AS total_tickets,
    COALESCE(tkt.avg_severity, 0) AS avg_severity,
    COALESCE(txn.successful_payments, 0) AS successful_payments,
    COALESCE(txn.failed_payments, 0) AS failed_payments,
    COALESCE(txn.total_revenue, 0) AS total_revenue,
    COALESCE(txn.recency_days, 9999) AS recency_days,
    COALESCE(svc.tenure_days, 0) AS tenure_days,
    CASE
        WHEN c.retention_risk_score >= 70 THEN 1
        ELSE 0
    END AS churn_label
FROM customers c
LEFT JOIN svc ON c.customer_id = svc.customer_id
LEFT JOIN tkt ON c.customer_id = tkt.customer_id
LEFT JOIN txn ON c.customer_id = txn.customer_id;

------------------------------------------------------------
-- ✅ REFACTORED ML VIEW: ROUTING FEATURES (FAN-OUT SAFE)
------------------------------------------------------------
DROP VIEW IF EXISTS vw_ml_routing_features;

CREATE VIEW vw_ml_routing_features AS
WITH
tkt AS (
    SELECT
        customer_id,
        service_id,
        COUNT(*) AS ticket_volume,
        AVG(severity_level) AS avg_severity
    FROM tickets
    GROUP BY customer_id, service_id
),
txn AS (
    SELECT
        customer_id,
        SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) AS recent_failed_payments
    FROM transactions
    WHERE transaction_date >= datetime('now', '-90 days')
    GROUP BY customer_id
),
outg AS (
    SELECT
        service_id,
        1 AS active_outage_flag
    FROM outages
    WHERE status = 'ACTIVE'
    GROUP BY service_id
)
SELECT
    cs.customer_id,
    cs.service_id,
    cs.plan_id,
    COALESCE(outg.active_outage_flag, 0) AS active_outage_flag,
    COALESCE(tkt.ticket_volume, 0) AS ticket_volume,
    COALESCE(tkt.avg_severity, 0) AS avg_severity,
    COALESCE(txn.recent_failed_payments, 0) AS recent_failed_payments,
    (
        COALESCE(outg.active_outage_flag, 0) * 2 +
        COALESCE(tkt.avg_severity, 0) +
        COALESCE(txn.recent_failed_payments, 0)
    ) AS routing_priority_score
FROM customer_services cs
LEFT JOIN tkt
    ON cs.customer_id = tkt.customer_id
   AND cs.service_id  = tkt.service_id
LEFT JOIN txn ON cs.customer_id = txn.customer_id
LEFT JOIN outg ON cs.service_id = outg.service_id;

------------------------------------------------------------
PRAGMA foreign_keys = ON;
------------------------------------------------------------
